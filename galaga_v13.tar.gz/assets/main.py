# -*- coding: utf-8 -*-
import pygame, asyncio, random, math, os, sys

# Web detection - must be before resource_path
IS_WEB = sys.platform in ("emscripten", "wasi")

# ============================================================
# RESOURCE PATH  (PyInstaller --onefile + pygbag compatible)
# ============================================================
def resource_path(rel):
    """Works for: normal run, PyInstaller --onefile, pygbag web"""
    if IS_WEB:
        return rel   # pygbag handles paths relative to main.py
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, rel)
    base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, rel)

IMG_DIR   = resource_path("game_image")
MUSIC_DIR = resource_path("game_music")

# ============================================================
# INIT
# ============================================================
pygame.init()


try:
    if IS_WEB:
        # web: 22050Hz mono small buffer - pygbag recommended
        pygame.mixer.pre_init(22050, -16, 1, 512)
    else:
        pygame.mixer.pre_init(44100, -16, 1, 512)
    pygame.mixer.init()
    SOUND_ENABLED = True
except:
    SOUND_ENABLED = False

WIDTH, HEIGHT = 480, 720
FPS = 60
screen = pygame.display.set_mode((WIDTH,HEIGHT))
pygame.display.set_caption("NOVALANCE")
clock = pygame.time.Clock()

font       = pygame.font.Font(None,24)
big_font   = pygame.font.Font(None,44)
small_font = pygame.font.Font(None,18)
tiny_font  = pygame.font.Font(None,14)

BLACK  =(0,0,0);     WHITE =(255,255,255); RED   =(255,60,60)
GREEN  =(0,255,100); BLUE  =(0,150,255);   YELLOW=(255,255,0)
CYAN   =(0,255,255); ORANGE=(255,150,0);   PURPLE=(200,50,200)
GRAY   =(100,100,100);PINK =(255,100,180); GOLD  =(255,215,0)
TEAL   =(0,200,180); LIME  =(150,255,0);   NAVY  =(20,20,120)

# IMG_DIR defined above via resource_path
STARS_SLOW=[(random.randint(0,WIDTH),random.randint(0,HEIGHT),random.choice([1,1,2])) for _ in range(60)]
STARS_FAST=[(random.randint(0,WIDTH),random.randint(0,HEIGHT),1) for _ in range(30)]
STARS_TWINKLE=[(random.randint(0,WIDTH),random.randint(0,HEIGHT),random.randint(2,4),random.random()*math.pi*2) for _ in range(18)]
BG_THEMES=[
    {"name":"Deep Space",   "sky":(2,2,8),   "neb":(20,10,40,18),  "planet":None},
    {"name":"Blue Nebula",  "sky":(2,5,15),  "neb":(10,20,80,22),  "planet":(80,120,200)},
    {"name":"Purple Void",  "sky":(8,2,15),  "neb":(40,10,80,25),  "planet":(120,60,180)},
    {"name":"Red Giant",    "sky":(15,3,3),  "neb":(80,20,20,22),  "planet":(200,80,40)},
    {"name":"Teal Storm",   "sky":(2,12,12), "neb":(10,60,80,22),  "planet":(0,160,140)},
    {"name":"Nova Field",   "sky":(15,8,2),  "neb":(80,50,10,25),  "planet":(220,140,0)},
    {"name":"Dark Matter",  "sky":(5,5,5),   "neb":(30,30,30,30),  "planet":(80,80,100)},
    {"name":"Crimson Zone", "sky":(18,2,2),  "neb":(100,10,10,30), "planet":(200,40,40)},
    {"name":"Void Edge",    "sky":(10,2,18), "neb":(60,5,100,35),  "planet":(150,20,200)},
    {"name":"Final Sector", "sky":(20,0,0),  "neb":(120,0,20,40),  "planet":(255,30,30)},
]
_nebula_cache={}
def get_nebula(tier):
    if tier not in _nebula_cache:
        t=BG_THEMES[min(tier,9)]; r,g,b,a=t["neb"]
        s=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
        for _ in range(5):
            nx=random.randint(0,WIDTH); ny=random.randint(0,HEIGHT); nr=random.randint(50,100)
            ns=pygame.Surface((nr*2,nr*2),pygame.SRCALPHA)
            pygame.draw.ellipse(ns,(r,g,b,a),(0,0,nr*2,nr*2))
            s.blit(ns,(nx-nr,ny-nr))
        _nebula_cache[tier]=s
    return _nebula_cache[tier]

class GameStats:
    def __init__(self):
        self.total_kills=0; self.coins=0; self.skin="default"
        self.powerups_collected=0; self.high_score=0
        self.pilot_xp=0; self.pilot_level=1
        self.upgrades={"atk":0,"spd":0,"def":0,"luck":0}
        self.owned_skins={"default"}
        self.active_title=""
        self.unlocked_titles=set()
        self.max_stage_cleared=0   # highest stage cleared
        self.run_scores={}         # stage -> best score
    def xp_to_next(self): return 200+self.pilot_level*150
    def add_xp(self,xp):
        self.pilot_xp+=xp; leveled=False
        while self.pilot_xp>=self.xp_to_next():
            self.pilot_xp-=self.xp_to_next()
            self.pilot_level+=1; leveled=True
        return leveled
    def upgrade_bonus(self,key): return self.upgrades.get(key,0)*0.08
    def unlock_title(self,title):
        if title not in self.unlocked_titles:
            self.unlocked_titles.add(title)
            if not self.active_title: self.active_title=title
            return True
        return False
    def _save_path(self):
        if hasattr(sys,'_MEIPASS'):
            return os.path.join(os.path.dirname(sys.executable),"novalance_save.json")
        return os.path.join(os.path.dirname(os.path.abspath(__file__)),"novalance_save.json")
    def save(self):
        if IS_WEB: return   # no file I/O on web
        try:
            import json
            data={"coins":self.coins,"skin":self.skin,"high_score":self.high_score,
                  "pilot_xp":self.pilot_xp,"pilot_level":self.pilot_level,
                  "upgrades":self.upgrades,"owned_skins":list(self.owned_skins),
                  "active_title":self.active_title,
                  "unlocked_titles":list(self.unlocked_titles),
                  "max_stage_cleared":self.max_stage_cleared,
                  "total_kills":self.total_kills}
            with open(self._save_path(),"w") as f: json.dump(data,f)
        except: pass
    def load(self):
        if IS_WEB: return   # no file I/O on web
        try:
            import json
            with open(self._save_path(),"r") as f: data=json.load(f)
            self.coins=data.get("coins",0)
            self.skin=data.get("skin","default")
            self.high_score=data.get("high_score",0)
            self.pilot_xp=data.get("pilot_xp",0)
            self.pilot_level=data.get("pilot_level",1)
            self.upgrades=data.get("upgrades",{"atk":0,"spd":0,"def":0,"luck":0})
            self.owned_skins=set(data.get("owned_skins",["default"]))
            self.active_title=data.get("active_title","")
            self.unlocked_titles=set(data.get("unlocked_titles",[]))
            self.max_stage_cleared=data.get("max_stage_cleared",0)
            self.total_kills=data.get("total_kills",0)
        except: pass

stats=GameStats(); stats.load()

# ============================================================
# ACHIEVEMENT SYSTEM
# ============================================================
ACHIEVEMENTS=[
    {"id":"first_blood",  "name":"First Blood",      "desc":"Kill your first enemy",          "req":("kills",1),    "reward":100,  "done":False},
    {"id":"combo50",      "name":"Combo King",        "desc":"Reach 50-hit combo",             "req":("combo",50),   "reward":500,  "done":False},
    {"id":"boss_nodmg",   "name":"Untouchable",       "desc":"Defeat a boss without taking damage","req":("boss_nodmg",1),"reward":2000,"done":False},
    {"id":"kills100",     "name":"Century",           "desc":"Kill 100 enemies",               "req":("kills",100),  "reward":300,  "done":False},
    {"id":"kills500",     "name":"Exterminator",      "desc":"Kill 500 enemies",               "req":("kills",500),  "reward":1000, "done":False},
    {"id":"stage10",      "name":"Deep Space",        "desc":"Reach stage 10",                 "req":("stage",10),   "reward":1500, "done":False},
    {"id":"pilot10",      "name":"Ace Pilot",         "desc":"Reach pilot level 10",           "req":("pilot",10),   "reward":3000, "done":False},
    {"id":"score100k",    "name":"Centurion",         "desc":"Score 100,000 points",           "req":("score",100000),"reward":2000,"done":False},
    {"id":"ally",         "name":"Wing Commander",    "desc":"Summon the Phoenix ally",        "req":("ally",1),     "reward":500,  "done":False},
    {"id":"streak30",     "name":"GODLIKE",           "desc":"Get a 30-kill streak",           "req":("streak",30),  "reward":5000, "done":False},
]

class AchievementSystem:
    def __init__(self):
        self.unlocked=set()
        self.notify_queue=[]   # (name, reward) to flash on screen
        self.notify_timer=0
    def check(self,kills=0,combo=0,stage=0,pilot=0,score=0,boss_nodmg=0,streak=0,ally=0):
        for ach in ACHIEVEMENTS:
            if ach["id"] in self.unlocked: continue
            rid,rval=ach["req"]
            met=False
            if rid=="kills" and kills>=rval: met=True
            elif rid=="combo" and combo>=rval: met=True
            elif rid=="boss_nodmg" and boss_nodmg>=rval: met=True
            elif rid=="stage" and stage>=rval: met=True
            elif rid=="pilot" and pilot>=rval: met=True
            elif rid=="score" and score>=rval: met=True
            elif rid=="streak" and streak>=rval: met=True
            elif rid=="ally" and ally>=rval: met=True
            if met:
                self.unlocked.add(ach["id"])
                stats.coins+=ach["reward"]
                self.notify_queue.append((ach["name"],ach["reward"],ach["desc"]))
    def update(self):
        if self.notify_timer>0: self.notify_timer-=1
        elif self.notify_queue: self.notify_timer=220
    def draw(self,s):
        if self.notify_timer>0 and self.notify_queue:
            name,reward,desc=self.notify_queue[0]
            if self.notify_timer<20: self.notify_queue.pop(0)
            t=min(1.0,self.notify_timer/30)
            # slide in from right
            ox=int((1-t)*200)
            panel=pygame.Surface((230,58),pygame.SRCALPHA)
            panel.fill((20,20,50,int(220*t)))
            pygame.draw.rect(panel,(255,200,50,int(200*t)),(0,0,230,58),2,border_radius=10)
            s.blit(panel,(WIDTH-246+ox,HEIGHT//2-29))
            hdr=small_font.render("ACHIEVEMENT!",True,(255,200,50))
            hdr.set_alpha(int(255*t))
            s.blit(hdr,(WIDTH-240+ox,HEIGHT//2-26))
            nm=font.render(name,True,WHITE)
            nm.set_alpha(int(255*t))
            s.blit(nm,(WIDTH-240+ox,HEIGHT//2-8))
            rw=tiny_font.render(f"+{reward} coins  |  {desc}",True,(180,180,220))
            rw.set_alpha(int(200*t))
            s.blit(rw,(WIDTH-240+ox,HEIGHT//2+16))

achievements=AchievementSystem()

# ============================================================
# DAILY MISSION
# ============================================================
MISSION_POOL=[
    {"id":"kill50",  "name":"Exterminador",  "desc":"Kill 50 enemies today",    "goal":50,  "type":"kills", "reward":200},
    {"id":"kill100", "name":"Massacre",      "desc":"Kill 100 enemies today",   "goal":100, "type":"kills", "reward":500},
    {"id":"combo20", "name":"Combo Rush",    "desc":"Reach 20-hit combo",       "goal":20,  "type":"combo", "reward":300},
    {"id":"stage5",  "name":"Veteran",       "desc":"Clear stage 5",            "goal":5,   "type":"stage", "reward":800},
    {"id":"score50k","name":"High Roller",   "desc":"Score 50,000 in one run",  "goal":50000,"type":"score","reward":600},
    {"id":"boss3",   "name":"Boss Hunter",   "desc":"Defeat 3 bosses",          "goal":3,   "type":"boss",  "reward":1000},
]

class DailyMission:
    def __init__(self):
        import random as _r
        self.mission=_r.choice(MISSION_POOL)
        self.progress=0; self.done=False
        self.claimed=False; self.flash=0
    def update(self,kills=0,combo=0,stage=0,score=0,boss=0):
        if self.done or self.claimed: return
        t=self.mission["type"]
        if   t=="kills": self.progress=max(self.progress,kills)
        elif t=="combo": self.progress=max(self.progress,combo)
        elif t=="stage": self.progress=max(self.progress,stage)
        elif t=="score": self.progress=max(self.progress,score)
        elif t=="boss":  self.progress=boss
        if self.progress>=self.mission["goal"] and not self.done:
            self.done=True; self.flash=180
            stats.coins+=self.mission["reward"]
    def draw_hud(self,s):
        m=self.mission
        ratio=min(1.0,self.progress/max(1,m["goal"]))
        col=(50,200,80) if self.done else (100,160,255)
        bx=WIDTH-130; by=90
        lbl=tiny_font.render(f"MISSION: {m['name']}",True,col)
        s.blit(lbl,(bx,by))
        pygame.draw.rect(s,(30,30,50),(bx,by+14,118,6),border_radius=3)
        pygame.draw.rect(s,col,(bx,by+14,int(118*ratio),6),border_radius=3)
        prog=tiny_font.render(f"{min(self.progress,m['goal'])}/{m['goal']}",True,(160,160,200))
        s.blit(prog,(bx,by+22))
        if self.done and self.flash>0:
            self.flash-=1
            fl=small_font.render(f"MISSION COMPLETE! +{m['reward']}c",True,(80,255,120))
            fl.set_alpha(min(255,self.flash*3))
            s.blit(fl,(WIDTH//2-fl.get_width()//2,HEIGHT//2+50))

daily=DailyMission()

# ============================================================
# UPGRADE TREE (permanent, coin-based)
# ============================================================
UPGRADE_TREE=[
    {"id":"bullet_spd",  "name":"Bullet Speed",   "desc":"+15% bullet speed",     "max":3,"cost":[150,300,600], "icon":">>"},
    {"id":"fire_rate",   "name":"Fire Rate",      "desc":"-1 frame cooldown",     "max":3,"cost":[200,400,800], "icon":"~"},
    {"id":"score_bonus", "name":"Score Boost",    "desc":"+10% score per kill",   "max":3,"cost":[100,250,500], "icon":"$"},
    {"id":"hull",        "name":"Hull Armor",     "desc":"+1 invincibility sec",  "max":3,"cost":[300,600,1200],"icon":"O"},
    {"id":"magnet",      "name":"Coin Magnet",    "desc":"Coins attract to ship", "max":3,"cost":[200,400,800], "icon":"M"},
    {"id":"multi_shot",  "name":"Multi-Shot",     "desc":"Extra side bullets",    "max":2,"cost":[500,1000],    "icon":"*"},
]

class UpgradeTree:
    def __init__(self):
        self.levels={u["id"]:0 for u in UPGRADE_TREE}
    def can_buy(self,uid):
        u=next(x for x in UPGRADE_TREE if x["id"]==uid)
        lv=self.levels[uid]
        if lv>=u["max"]: return False,0
        cost=u["cost"][lv]
        return stats.coins>=cost, cost
    def buy(self,uid):
        ok,cost=self.can_buy(uid)
        if not ok: return False
        stats.coins-=cost
        self.levels[uid]+=1
        return True
    def get(self,uid): return self.levels.get(uid,0)

upgrade_tree=UpgradeTree()

# ============================================================
# LOCAL RANKING
# ============================================================
class RankingSystem:
    def __init__(self):
        self.scores=[]   # list of (score, stage, pilot_level, name)
    def submit(self,score,stage,pilot_level,name="YOU"):
        self.scores.append((score,stage,pilot_level,name))
        self.scores.sort(key=lambda x:-x[0])
        self.scores=self.scores[:5]
    def draw(self,s):
        ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
        ov.fill((0,0,20,230)); s.blit(ov,(0,0))
        hdr=big_font.render("NOVALANCE  RANKING",True,GOLD)
        s.blit(hdr,(WIDTH//2-hdr.get_width()//2,30))
        pygame.draw.line(s,GRAY,(30,68),(WIDTH-30,68),1)
        medals=["1ST","2ND","3RD","4TH","5TH"]
        mcols=[(255,200,50),(200,200,200),(180,120,60),(160,160,160),(140,140,140)]
        for i,(sc,st,pl,nm) in enumerate(self.scores[:5]):
            y=82+i*58
            mc=mcols[i]; medal=medals[i]
            panel=pygame.Surface((WIDTH-40,52),pygame.SRCALPHA)
            if i==0: panel.fill((60,50,0,180))
            else:    panel.fill((15,15,40,160))
            pygame.draw.rect(panel,(mc[0]//2,mc[1]//2,mc[2]//2,160),(0,0,WIDTH-40,52),1,border_radius=8)
            s.blit(panel,(20,y))
            ml=font.render(medal,True,mc); s.blit(ml,(34,y+14))
            nl=font.render(nm,True,WHITE); s.blit(nl,(80,y+8))
            sl=tiny_font.render(f"Stage {st}  Pilot Lv.{pl}",True,(160,160,200)); s.blit(sl,(80,y+28))
            scl=font.render(f"{sc:,}",True,mc)
            s.blit(scl,(WIDTH-scl.get_width()-34,y+14))
        if not self.scores:
            empty=font.render("No records yet!",True,GRAY)
            s.blit(empty,(WIDTH//2-empty.get_width()//2,HEIGHT//2))
        hint=tiny_font.render("Press R to play again",True,(100,100,140))
        s.blit(hint,(WIDTH//2-hint.get_width()//2,HEIGHT-22))

ranking=RankingSystem()

# ============================================================
# KILL EFFECT SYSTEM (slowmo killcam + lightning border)
# ============================================================
class KillEffect:
    def __init__(self):
        self.slowmo=0          # frames of slow motion
        self.slowmo_target=0   # zoom target x,y
        self.lightning_border=0
        self.border_col=(255,200,50)
        self.zoom_x=0; self.zoom_y=0
    def boss_kill(self,x,y):
        self.slowmo=90; self.zoom_x=x; self.zoom_y=y
        self.lightning_border=60; self.border_col=(255,100,50)
    def streak_lightning(self,combo,col):
        if combo>=10:
            self.lightning_border=max(self.lightning_border,40)
            self.border_col=col
    def update(self):
        if self.slowmo>0: self.slowmo-=1
        if self.lightning_border>0: self.lightning_border-=1
    @property
    def is_slow(self): return self.slowmo>0
    def draw_border(self,s):
        if self.lightning_border<=0: return
        t=self.lightning_border/60
        r,g,b=self.border_col
        # random lightning segments - direct draw, no Surface
        for _ in range(int(3*t)):
            side=random.randint(0,3)
            if   side==0: x1,y1=random.randint(0,WIDTH),0
            elif side==1: x1,y1=WIDTH,random.randint(0,HEIGHT)
            elif side==2: x1,y1=random.randint(0,WIDTH),HEIGHT
            else:          x1,y1=0,random.randint(0,HEIGHT)
            x2=x1+random.randint(-40,40); y2=y1+random.randint(-40,40)
            pygame.draw.line(s,(r,g,b),(x1,y1),(x2,y2),2)
        # solid border
        bw=max(1,int(4*t))
        pygame.draw.rect(s,(r,g,b),(0,0,WIDTH,bw))
        pygame.draw.rect(s,(r,g,b),(0,HEIGHT-bw,WIDTH,bw))
        pygame.draw.rect(s,(r,g,b),(0,0,bw,HEIGHT))
        pygame.draw.rect(s,(r,g,b),(WIDTH-bw,0,bw,HEIGHT))

kill_effect=KillEffect()

# ============================================================
# SKIN SYSTEM
# ============================================================
SKINS=[
    {"id":"default",   "name":"BLUE FALCON",   "cols":[(0,180,255),(0,100,200),(0,220,255)],   "price":0,    "desc":"Default ship"},
    {"id":"crimson",   "name":"CRIMSON BLADE",  "cols":[(255,60,60),(180,20,20),(255,120,120)], "price":300,  "desc":"Red hot fighter"},
    {"id":"emerald",   "name":"EMERALD WING",   "cols":[(60,255,120),(20,160,60),(150,255,180)],"price":300,  "desc":"Nature's fury"},
    {"id":"phantom",   "name":"PHANTOM GREY",   "cols":[(180,180,200),(100,100,120),(220,220,240)],"price":500,"desc":"Stealth operative"},
    {"id":"gold",      "name":"GOLDEN LANCE",   "cols":[(255,200,50),(180,130,0),(255,240,120)],"price":800,  "desc":"Legendary pilot only"},
    {"id":"aurora",    "name":"AURORA",          "cols":[(180,80,255),(80,0,200),(220,150,255)], "price":600,  "desc":"Cosmic energy"},
    {"id":"neon",      "name":"NEON STRIKE",    "cols":[(0,255,220),(0,180,150),(100,255,240)], "price":400,  "desc":"Electric speed"},
    {"id":"shadow",    "name":"SHADOW VOID",    "cols":[(40,0,80),(20,0,50),(120,50,200)],      "price":700,  "desc":"From the dark zone"},
]

def get_skin_col():
    sk=next((s for s in SKINS if s["id"]==stats.skin),SKINS[0])
    return sk["cols"][0]

# ============================================================
# TITLE SYSTEM
# ============================================================
TITLES=[
    {"id":"rookie",    "name":"Rookie Pilot",    "col":(180,180,180),"from":"first_blood"},
    {"id":"hunter",    "name":"Enemy Hunter",     "col":(255,180,80), "from":"kills100"},
    {"id":"exterminator","name":"Exterminator",  "col":(255,100,50), "from":"kills500"},
    {"id":"combo",     "name":"Combo King",       "col":(80,200,255), "from":"combo50"},
    {"id":"untouchable","name":"Untouchable",     "col":(0,255,180),  "from":"boss_nodmg"},
    {"id":"ace",       "name":"Ace Pilot",        "col":(255,220,50), "from":"pilot10"},
    {"id":"deep",      "name":"Deep Space Vet",   "col":(100,150,255),"from":"stage10"},
    {"id":"godlike",   "name":"GODLIKE",          "col":(255,50,50),  "from":"streak30"},
    {"id":"legend",    "name":"LEGENDARY",        "col":(255,200,50), "from":"score100k"},
    {"id":"commander", "name":"Wing Commander",   "col":(255,220,80), "from":"ally"},
    {"id":"champion",  "name":"NOVALANCE CHAMPION","col":(255,255,255),"from":"stage100"},
]

def draw_skin_shop(surface, sel=0):
    ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); ov.fill((0,0,20,225)); surface.blit(ov,(0,0))
    hdr=big_font.render("HANGAR",True,GOLD)
    surface.blit(hdr,(WIDTH//2-hdr.get_width()//2,8))
    cl=font.render(f"Coins: {stats.coins}",True,GOLD)
    surface.blit(cl,(WIDTH//2-cl.get_width()//2,42))
    pygame.draw.line(surface,GRAY,(20,64),(WIDTH-20,64),1)
    item_h=62
    for i,sk in enumerate(SKINS):
        y=70+i*item_h; owned=sk["id"] in stats.owned_skins
        active=sk["id"]==stats.skin; selected=(i==sel)
        col=sk["cols"][0]; col2=sk["cols"][2]
        row=pygame.Surface((WIDTH-32,item_h-4),pygame.SRCALPHA)
        if active: row.fill((*col,40))
        elif selected: row.fill((20,20,60,200))
        else: row.fill((12,12,35,160))
        bc=col if (selected or active) else (50,50,70,160)
        pygame.draw.rect(row,(*bc[:3],200),(0,0,WIDTH-32,item_h-4),2,border_radius=8)
        surface.blit(row,(16,y))
        # mini ship preview
        preview_x=44; preview_y=y+item_h//2-2
        pygame.draw.polygon(surface,col,[(preview_x,preview_y-14),(preview_x+12,preview_y+8),(preview_x-12,preview_y+8)])
        pygame.draw.polygon(surface,col2,[(preview_x-12,preview_y+8),(preview_x-18,preview_y+12),(preview_x-4,preview_y+2)])
        pygame.draw.polygon(surface,col2,[(preview_x+12,preview_y+8),(preview_x+18,preview_y+12),(preview_x+4,preview_y+2)])
        pygame.draw.circle(surface,(200,230,255),(preview_x,preview_y-4),4)
        # name & desc
        nc=WHITE if (selected or active) else (180,180,180)
        nm=font.render(sk["name"],True,col if active else nc)
        surface.blit(nm,(68,y+8))
        dc=tiny_font.render(("* EQUIPPED" if active else sk["desc"]),True,GOLD if active else (130,130,160))
        surface.blit(dc,(68,y+30))
        # price / owned
        if owned:
            pr=small_font.render("OWNED",True,(80,200,80))
        else:
            can=stats.coins>=sk["price"]
            pr=small_font.render(f"{sk['price']}c",True,GOLD if can else RED)
        surface.blit(pr,(WIDTH-62,y+item_h//2-pr.get_height()//2))
    # close button
    close_r=pygame.Rect(WIDTH-44,6,36,36)
    pygame.draw.rect(surface,(180,40,40),close_r,border_radius=8)
    pygame.draw.rect(surface,(255,100,100),close_r,2,border_radius=8)
    xl=font.render("X",True,WHITE); surface.blit(xl,xl.get_rect(center=close_r.center))
    hint=tiny_font.render("UP/DOWN: Select  ENTER/Tap: Buy/Equip  Tab/X: Close",True,(80,80,120))
    surface.blit(hint,(WIDTH//2-hint.get_width()//2,HEIGHT-16))

def draw_title_select(surface, sel=0):
    ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); ov.fill((0,0,20,225)); surface.blit(ov,(0,0))
    hdr=big_font.render("TITLES",True,GOLD)
    surface.blit(hdr,(WIDTH//2-hdr.get_width()//2,8))
    pygame.draw.line(surface,GRAY,(20,52),(WIDTH-20,52),1)
    item_h=52
    for i,t in enumerate(TITLES):
        y=58+i*item_h
        unlocked=t["id"] in stats.unlocked_titles
        active=stats.active_title==t["id"]
        selected=(i==sel)
        col=t["col"] if unlocked else (60,60,70)
        row=pygame.Surface((WIDTH-32,item_h-4),pygame.SRCALPHA)
        if active: row.fill((*t["col"],40))
        elif selected and unlocked: row.fill((20,20,60,200))
        else: row.fill((12,12,35,100) if unlocked else (8,8,20,80))
        pygame.draw.rect(row,(*col[:3],180),(0,0,WIDTH-32,item_h-4),2 if (selected or active) else 1,border_radius=8)
        surface.blit(row,(16,y))
        lk=font.render(t["name"],True,col)
        surface.blit(lk,(36,y+8))
        src_ach=next((a for a in ACHIEVEMENTS if a["id"]==t.get("from","")),None)
        if src_ach:
            sub=tiny_font.render(src_ach["desc"] if unlocked else f"Unlock: {src_ach['desc']}",True,(140,140,160) if unlocked else (80,80,90))
            surface.blit(sub,(36,y+28))
        if active:
            al=tiny_font.render("ACTIVE",True,GOLD); surface.blit(al,(WIDTH-70,y+16))
        elif not unlocked:
            al=tiny_font.render("LOCKED",True,(80,80,80)); surface.blit(al,(WIDTH-70,y+16))
    close_r=pygame.Rect(WIDTH-44,6,36,36)
    pygame.draw.rect(surface,(180,40,40),close_r,border_radius=8)
    xl=font.render("X",True,WHITE); surface.blit(xl,xl.get_rect(center=close_r.center))
    hint=tiny_font.render("Tap to equip title  |  Tab/X: Close",True,(80,80,120))
    surface.blit(hint,(WIDTH//2-hint.get_width()//2,HEIGHT-16))

def draw_stage_select(surface, sel=0):
    ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); ov.fill((0,0,20,225)); surface.blit(ov,(0,0))
    hdr=big_font.render("STAGE SELECT",True,CYAN)
    surface.blit(hdr,(WIDTH//2-hdr.get_width()//2,8))
    sub=small_font.render(f"Cleared: Stage {stats.max_stage_cleared}",True,(160,200,255))
    surface.blit(sub,(WIDTH//2-sub.get_width()//2,44))
    pygame.draw.line(surface,GRAY,(20,66),(WIDTH-20,66),1)
    # show stages 1-100 in a grid
    cols=10; cell_w=(WIDTH-32)//cols; cell_h=32
    rows=10
    for row in range(rows):
        for col in range(cols):
            stage=row*cols+col+1
            x=16+col*cell_w; y=72+row*cell_h
            cleared=stage<=stats.max_stage_cleared
            locked=stage>stats.max_stage_cleared+1
            is_boss=(stage%10==0)
            is_sel=(stage-1==sel)
            bg=(30,0,0,200) if is_boss and cleared else (0,30,0,200) if cleared else (20,20,40,160)
            col_rect=pygame.Surface((cell_w-3,cell_h-3),pygame.SRCALPHA)
            col_rect.fill(bg)
            border=(255,200,50) if is_boss else ((0,200,100) if cleared else (50,50,80))
            if is_sel: border=(0,200,255)
            pygame.draw.rect(col_rect,(*border[:3],220),(0,0,cell_w-3,cell_h-3),2 if is_sel else 1,border_radius=4)
            surface.blit(col_rect,(x,y))
            tc=(255,200,50) if is_boss else (200,255,200) if cleared else (80,80,100) if locked else WHITE
            tl=tiny_font.render(str(stage),True,tc)
            surface.blit(tl,tl.get_rect(center=(x+cell_w//2-2,y+cell_h//2-2)))
    # selected stage info
    sel_stage=sel+1
    iy=72+rows*cell_h+8
    tier=(sel_stage-1)//10
    theme=PLANET_THEMES[tier%len(PLANET_THEMES)]
    info=font.render(f"Stage {sel_stage}  -  {theme['name']}",True,theme["accent"])
    surface.blit(info,(WIDTH//2-info.get_width()//2,iy))
    avail=sel_stage<=stats.max_stage_cleared+1
    av=small_font.render("ENTER to start" if avail else "LOCKED",True,CYAN if avail else RED)
    surface.blit(av,(WIDTH//2-av.get_width()//2,iy+24))
    close_r=pygame.Rect(WIDTH-44,6,36,36)
    pygame.draw.rect(surface,(180,40,40),close_r,border_radius=8)
    xl=font.render("X",True,WHITE); surface.blit(xl,xl.get_rect(center=close_r.center))

def draw_ending(surface, tick):
    """Stage 100 clear ending screen"""
    surface.fill((0,0,8))
    # star field
    random.seed(42)
    for _ in range(120):
        sx=random.randint(0,WIDTH); sy=random.randint(0,HEIGHT)
        sa=int(100+math.sin(tick*0.03+sx)*80)
        pygame.draw.circle(surface,(200,200,255),(sx,sy),1)
    random.seed()
    # expanding ring effect
    for i in range(4):
        r=int((tick*2+i*60)%300)
        if r>0:
            a=max(0,200-r)
            rs=pygame.Surface((r*2+4,r*2+4),pygame.SRCALPHA)
            pygame.draw.circle(rs,(100,150,255,a),(r+2,r+2),r,2)
            surface.blit(rs,(WIDTH//2-r-2,HEIGHT//2-r-2))
    # NOVA LANCE title glow
    pulse=abs(math.sin(tick*0.04))*60+160
    tf=pygame.font.Font(None,72)
    for ox,oy in [(-2,0),(2,0),(0,-2),(0,2)]:
        gl=tf.render("NOVALANCE",True,(int(pulse*0.3),int(pulse*0.4),int(pulse)))
        gl.set_alpha(80); surface.blit(gl,(WIDTH//2-gl.get_width()//2+ox,80+oy))
    title=tf.render("NOVALANCE",True,(int(pulse),int(pulse),255))
    surface.blit(title,(WIDTH//2-title.get_width()//2,80))
    # MISSION COMPLETE
    if tick>60:
        t2=min(1.0,(tick-60)/40)
        mc=big_font.render("MISSION COMPLETE",True,(255,200,50))
        mc.set_alpha(int(255*t2))
        surface.blit(mc,(WIDTH//2-mc.get_width()//2,160))
    if tick>120:
        t3=min(1.0,(tick-120)/40)
        lines=[
            "You have conquered all 100 stages of NOVALANCE.",
            "The galaxy is safe. For now.",
            f"Final Score: {stats.high_score:,}",
            f"Pilot Level: {stats.pilot_level}",
            f"Total Kills: {stats.total_kills:,}",
        ]
        for i,line in enumerate(lines):
            lc=(255,220,50) if "Score" in line or "Level" in line or "Kills" in line else (200,210,255)
            ls=font.render(line,True,lc)
            ls.set_alpha(int(255*t3))
            surface.blit(ls,(WIDTH//2-ls.get_width()//2,230+i*30))
    if tick>240:
        t4=min(1.0,(tick-240)/30)
        # fireworks
        for _ in range(int(3*t4)):
            fx=random.randint(30,WIDTH-30); fy=random.randint(50,HEIGHT//2)
            fc=(random.randint(150,255),random.randint(100,255),random.randint(100,255))
            pygame.draw.circle(surface,fc,(fx,fy),random.randint(2,5))
    if tick>200 and (tick//40)%2==0:
        cont=font.render("Tap or R to return",True,(180,180,255))
        surface.blit(cont,(WIDTH//2-cont.get_width()//2,HEIGHT-40))




# ============================================================
# PLANET THEMES
# ============================================================
PLANET_THEMES = [
    {"name":"DEEP SPACE",   "bg":(0,0,0),       "tint":(0,0,0),       "star_col":(255,255,255), "accent":(100,100,255)},
    {"name":"NEBULA ZONE",  "bg":(8,0,18),       "tint":(5,0,12),      "star_col":(200,150,255), "accent":(180,80,255)},
    {"name":"MARS SECTOR",  "bg":(18,5,0),       "tint":(12,3,0),      "star_col":(255,180,120), "accent":(255,80,30)},
    {"name":"ICE FIELDS",   "bg":(0,8,18),       "tint":(0,5,12),      "star_col":(180,220,255), "accent":(0,200,255)},
    {"name":"JUPITER RING", "bg":(15,10,0),      "tint":(10,6,0),      "star_col":(255,220,150), "accent":(255,180,0)},
    {"name":"DARK ZONE",    "bg":(12,0,5),       "tint":(8,0,3),       "star_col":(255,100,150), "accent":(255,50,100)},
    {"name":"ASTEROID BELT","bg":(8,7,5),        "tint":(5,4,2),       "star_col":(200,190,170), "accent":(180,160,100)},
    {"name":"SOLAR FLARE",  "bg":(18,8,0),       "tint":(12,5,0),      "star_col":(255,200,80),  "accent":(255,140,0)},
    {"name":"BLOOD NEBULA", "bg":(18,0,0),       "tint":(12,0,0),      "star_col":(255,120,100), "accent":(255,30,30)},
    {"name":"OMEGA CORE",   "bg":(10,0,10),      "tint":(8,0,8),       "star_col":(220,180,255), "accent":(200,0,255)},
]

SHOP_ITEMS = [
    {"name":"Life +1",        "price":300, "type":"life",     "icon":"+",
     "desc":"Gain 1 extra life (max 5)",          "color":(255,80,80),   "max_buy":3,  "bought":0},
    {"name":"Shield",         "price":200, "type":"shield",   "icon":"O",
     "desc":"Activate protective shield",          "color":(0,220,180),   "max_buy":99, "bought":0},
    {"name":"Double Fighter", "price":400, "type":"double",   "icon":"=",
     "desc":"Fire 3 bullets at once (12s)",        "color":(0,200,255),   "max_buy":99, "bought":0},
    {"name":"Speed Up",       "price":250, "type":"speed",    "icon":">",
     "desc":"Move 1.5x faster (10s)",              "color":(255,200,0),   "max_buy":99, "bought":0},
    {"name":"Laser",          "price":350, "type":"laser",    "icon":"I",
     "desc":"Piercing laser beam (8s)",            "color":(180,80,255),  "max_buy":99, "bought":0},
    {"name":"Bomb",           "price":150, "type":"bomb",     "icon":"*",
     "desc":"Clear all enemies on screen",         "color":(255,50,50),   "max_buy":99, "bought":0},
    {"name":"Missiles x5",    "price":300, "type":"missile",  "icon":"^",
     "desc":"Auto-homing missiles (5 shots)",      "color":(255,140,0),   "max_buy":99, "bought":0},
    {"name":"Plasma x3",      "price":350, "type":"plasma",   "icon":"@",
     "desc":"Area plasma orbs (3 shots)",          "color":(0,255,150),   "max_buy":99, "bought":0},
    {"name":"Drone",          "price":500, "type":"drone",    "icon":"D",
     "desc":"Orbital attack drone (13s)",          "color":(200,200,0),   "max_buy":99, "bought":0},
    {"name":"Time Slow",      "price":450, "type":"timeslow", "icon":"T",
     "desc":"Slow enemies for 5s",                 "color":(100,180,255), "max_buy":99, "bought":0},
]


# ============================================================
# STAGE PLAN  (100 stages)
# ============================================================
def _build_plan():
    plan = {}
    # note
    boss_seq = {
        10:"scout", 20:"carrier", 30:"titan",  40:"phantom",
        50:"omega",  60:"hydra",   70:"mothership", 80:"berserker",
        90:"hydra2", 100:"omega2"
    }
    # note
    bonus_seq = ["bonus","rescue","asteroid","formation","meteor","ambush"]
    bonus_idx = 0

    for s in range(1,101):
        btype = boss_seq.get(s, None)

        # note
        if s % 5 == 0 and btype is None:
            etype = bonus_seq[bonus_idx % len(bonus_seq)]
            bonus_idx += 1
        else:
            etype = None

        # note
        tier = (s-1) // 10   # 0~9
        if tier == 0:
            mix=[("normal",9),("fast",1)]
        elif tier == 1:
            mix=[("fast",6),("normal",3),("elite",1)]
        elif tier == 2:
            mix=[("elite",5),("armored",3),("fast",2)]
        elif tier == 3:
            mix=[("armored",4),("splitter",4),("elite",2)]
        elif tier == 4:
            mix=[("ghost",4),("splitter",3),("armored",3)]
        elif tier == 5:
            mix=[("bomber",4),("ghost",3),("zigzag",3)]
        elif tier == 6:
            mix=[("zigzag",4),("bomber",3),("ghost",3)]
        elif tier == 7:
            mix=[("ghost",3),("bomber",3),("zigzag",2),("splitter",2)]
        elif tier == 8:
            mix=[("bomber",3),("zigzag",3),("ghost",2),("armored",2)]
        else:
            mix=[("zigzag",3),("ghost",3),("bomber",2),("splitter",2)]

        # note
        tints=[(0,0,0),(5,0,8),(0,8,8),(10,0,10),(0,0,15),
               (12,0,5),(5,5,0),(10,3,0),(12,0,0),(18,0,0)]
        tint=tints[min(tier,9)]

        plan[s]={"boss":btype,"event":etype,"mix":mix,"tint":tint,
                 "tier":tier,"enemy_scale":1.0+tier*0.15}
    return plan

STAGE_PLAN = _build_plan()

# ============================================================
# SOUND MANAGER
# ============================================================
class SoundManager:
    """Web-safe sound manager for pygbag."""
    def __init__(self):
        self.enabled     = SOUND_ENABLED
        self.sounds      = {}
        self.bgm_loaded  = False
        self.bgm_playing = False
        self._interacted = False
        self._load_sfx()
        self._load_bgm()

    def _load_sfx(self):
        sfx_files = [
            ("shoot",     os.path.join(MUSIC_DIR,"shoot.ogg")),
            ("explosion", os.path.join(MUSIC_DIR,"explosion.ogg")),
            ("powerup",   os.path.join(MUSIC_DIR,"powerup.ogg")),
        ]
        for name, path in sfx_files:
            try:
                snd = pygame.mixer.Sound(path)
                snd.set_volume(0.45)
                self.sounds[name] = snd
            except Exception as e:
                print(f"sfx skip {name}: {e}")

    def _load_bgm(self):
        try:
            fname = "bgm-pygbag.ogg" if IS_WEB else "bgm.ogg"
            pygame.mixer.music.load(os.path.join(MUSIC_DIR, fname))
            pygame.mixer.music.set_volume(0.28)
            self.bgm_loaded = True
        except Exception as e:
            self.bgm_loaded = False

    # Call on EVERY user event (click / touch / keydown)
    # Browser blocks audio until user gesture - this gates it
    def on_user_event(self):
        if not self._interacted:
            self._interacted = True
            self.play_bgm()

    def play(self, name):
        if not self.enabled: return
        snd = self.sounds.get(name)
        if snd:
            try: snd.play()
            except: pass

    def play_bgm(self, boss_mode=False):
        if not self.enabled: return
        if IS_WEB:
            track = os.path.join(MUSIC_DIR,"boss_bgm.ogg") if boss_mode else os.path.join(MUSIC_DIR,"bgm-pygbag.ogg")
        else:
            track = os.path.join(MUSIC_DIR,"boss_bgm.ogg") if boss_mode else os.path.join(MUSIC_DIR,"bgm.ogg")
        try:
            pygame.mixer.music.load(track)
            pygame.mixer.music.set_volume(0.38 if boss_mode else 0.28)
            pygame.mixer.music.play(-1)
            self.bgm_playing = True
            self.bgm_loaded  = True
        except Exception as e:
            self.bgm_loaded = False
        self.stop_bgm()
        self.play_bgm(boss_mode)

    def stop_bgm(self):
        try:
            pygame.mixer.music.stop()
            self.bgm_playing = False
        except: pass

    def toggle(self):
        self.enabled = not self.enabled
        if self.enabled: self.play_bgm()
        else: self.stop_bgm()

    def notify_interaction(self):
        self.on_user_event()

sounds = SoundManager()

# ============================================================
# PARTICLE / FLOAT TEXT
# ============================================================
class Particle:
    __slots__=('x','y','vx','vy','life','max_life','color','size','gravity','ptype','angle','rot_spd')
    def __init__(self,x,y,color,speed=2.5,gravity=0.0,ptype='circle'):
        self.x=x; self.y=y; self.ptype=ptype
        a=random.uniform(0,math.pi*2); spd=random.uniform(0.5,speed)
        self.vx=math.cos(a)*spd; self.vy=math.sin(a)*spd
        self.life=random.randint(18,45); self.max_life=self.life
        self.color=color; self.size=random.uniform(2,5); self.gravity=gravity
        self.angle=random.uniform(0,math.pi*2); self.rot_spd=random.uniform(-0.3,0.3)
    def update(self):
        self.x+=self.vx; self.y+=self.vy; self.vy+=self.gravity
        self.vx*=0.97; self.life-=1
        self.size=max(0,self.size*0.92); self.angle+=self.rot_spd
        return self.life>0
    def draw(self,s):
        if self.size<0.8: return
        rat=self.life/self.max_life
        r,g,b=self.color
        col=(int(r*rat),int(g*rat),int(b*rat))
        ix,iy=int(self.x),int(self.y); isz=max(1,int(self.size))
        if self.ptype=='star':
            # draw as simple diamond - no Surface allocation
            pts=[(ix,iy-isz),(ix+isz,iy),(ix,iy+isz),(ix-isz,iy)]
            pygame.draw.polygon(s,col,pts)
        elif self.ptype=='spark':
            ex=ix+int(self.vx*2); ey=iy+int(self.vy*2)
            pygame.draw.line(s,col,(ix,iy),(ex,ey),max(1,isz//2))
        else:
            pygame.draw.circle(s,col,(ix,iy),isz)

class ShockWave:
    def __init__(self,x,y,col=(255,200,50)):
        self.x=x; self.y=y; self.r=10; self.max_r=160; self.life=20; self.col=col
    def update(self):
        self.r+=10; self.life-=1; return self.life>0 and self.r<self.max_r
    def draw(self,s):
        if self.r<=0: return
        a=max(0,min(255,int(200*self.life/20)))
        r,g,b=self.col
        # draw 3 concentric circles with alpha fading - no Surface
        for dr,da in [(0,a),(4,a//2),(8,a//4)]:
            cr=self.r-dr
            if cr>0:
                pygame.draw.circle(s,(min(255,r+30),min(255,g+30),min(255,b+30)),(self.x,self.y),cr,2)

class FlashEffect:
    def __init__(self,col=(255,255,255),life=6):
        self.col=col; self.life=life; self.max_life=life
        # pre-allocate surface once
        self._surf=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
    def update(self): self.life-=1; return self.life>0
    def draw(self,s):
        a=int(80*self.life/self.max_life)
        self._surf.fill((*self.col,a)); s.blit(self._surf,(0,0))

class FloatText:
    def __init__(self,x,y,text,color=YELLOW,size=22,style='normal'):
        self.x=x; self.y=float(y); self.text=text; self.color=color
        self.life=70; self.max_life=70; self.fnt=pygame.font.Font(None,size)
        self.style=style  # 'normal','bounce','shake','streak'
        self.scale=1.0; self.target_scale=1.0; self.ox=0
        if style=='bounce': self.scale=2.0; self.target_scale=1.0
        if style=='streak': self.life=100; self.max_life=100; self.scale=1.8; self.target_scale=1.0
    def update(self):
        self.y-=0.9; self.life-=1
        if self.style=='bounce': self.scale=max(1.0,self.scale-0.08)
        if self.style=='streak': self.scale=max(1.0,self.scale-0.04)
        if self.style=='shake': self.ox=random.randint(-3,3)
        return self.life>0
    def draw(self,s):
        ratio=self.life/self.max_life
        surf=self.fnt.render(self.text,True,self.color)
        if self.style in ('bounce','streak') and abs(self.scale-1.0)>0.05:
            nw=int(surf.get_width()*self.scale); nh=int(surf.get_height()*self.scale)
            if nw>0 and nh>0: surf=pygame.transform.scale(surf,(nw,nh))
        if self.style=='streak':
            # glow effect
            glow=self.fnt.render(self.text,True,(255,255,255))
            glow.set_alpha(int(80*ratio))
            s.blit(glow,(self.x-glow.get_width()//2+self.ox-2,int(self.y)-2))
        surf.set_alpha(int(255*ratio))
        s.blit(surf,(self.x-surf.get_width()//2+self.ox,int(self.y)))

class ComboMeter:
    """Dramatic combo multiplier visualizer"""
    # (min_combo, mult, label, color, bg_color)
    TIERS=[
        (2,  1, "COMBO",       (255,220,80),  (80,60,0)),
        (5,  2, "DOUBLE!",     (80,220,255),  (0,50,80)),
        (10, 3, "TRIPLE!!",    (80,255,120),  (0,60,20)),
        (15, 4, "QUAD!!!",     (255,120,80),  (70,20,0)),
        (20, 5, "PENTA!!!!",   (220,80,255),  (50,0,70)),
        (25, 6, "HEXA!!!!!",   (255,60,60),   (80,0,0)),
        (30, 8, "GODLIKE!!!!!",(255,255,255), (60,0,60)),
    ]
    def __init__(self):
        self.combo=0; self.mult=1; self.decay=0; self.max_decay=150
        self.pulse=0.0; self.pop_scale=1.0; self.pop_alpha=0
        self.center_timer=0   # big center popup timer
        self.center_text=""; self.center_col=(255,255,255)
        self.last_tier=-1
        self.lightning_pts=[]  # screen edge lightning points
        self.lightning_timer=0
        self.shake_x=0; self.shake_y=0

    def _get_tier(self,combo):
        tier=self.TIERS[0]
        for t in self.TIERS:
            if combo>=t[0]: tier=t
        return tier

    def hit(self,combo,mult):
        old_tier=self._get_tier(max(0,combo-1))
        new_tier=self._get_tier(combo)
        self.combo=combo; self.mult=new_tier[1]
        self.decay=self.max_decay
        self.pop_scale=2.2; self.pop_alpha=255
        # tier change -> big center popup + lightning
        if new_tier[0]!=old_tier[0] and combo>=5:
            self.center_text=new_tier[2]
            self.center_col=new_tier[3]
            self.center_timer=55
            self._gen_lightning(new_tier[3])
        self.shake_x=random.randint(-4,4)
        self.shake_y=random.randint(-3,3)

    def reset(self):
        self.combo=0; self.mult=1; self.decay=0
        self.center_timer=0; self.last_tier=-1

    def _gen_lightning(self,col):
        """Generate random lightning bolt points around screen edge"""
        self.lightning_pts=[]
        self.lightning_timer=30
        for _ in range(6):
            side=random.randint(0,3)
            if side==0:   x=random.randint(0,WIDTH);  y=0
            elif side==1: x=WIDTH;  y=random.randint(0,HEIGHT)
            elif side==2: x=random.randint(0,WIDTH);  y=HEIGHT
            else:         x=0;  y=random.randint(0,HEIGHT)
            # zigzag to center
            pts=[(x,y)]
            cx,cy=WIDTH//2,HEIGHT//2
            steps=random.randint(4,8)
            for i in range(steps):
                t=(i+1)/(steps+1)
                nx=int(x+(cx-x)*t+random.randint(-30,30))
                ny=int(y+(cy-y)*t+random.randint(-30,30))
                pts.append((nx,ny))
            pts.append((cx,cy))
            self.lightning_pts.append((pts,col))

    def update(self):
        self.pulse=(self.pulse+0.15)%(math.pi*2)
        if self.decay>0: self.decay-=1
        else: self.reset(); return
        self.pop_scale=max(1.0,self.pop_scale-0.09)
        self.pop_alpha=max(0,self.pop_alpha-8)
        if self.center_timer>0: self.center_timer-=1
        if self.lightning_timer>0: self.lightning_timer-=1
        self.shake_x=int(self.shake_x*0.7)
        self.shake_y=int(self.shake_y*0.7)

    def draw(self,s):
        if self.combo<2: return
        t=self.decay/self.max_decay
        tier=self._get_tier(self.combo)
        col=tier[3]; bg=tier[4]

        # -- screen edge lightning --
        if self.lightning_timer>0:
            for pts,lc in self.lightning_pts:
                r,g,b=lc
                for i in range(len(pts)-1):
                    pygame.draw.line(s,(r,g,b),pts[i],pts[i+1],2)

        # -- HUD bar (top-left) --
        bx=8+self.shake_x; by=60+self.shake_y
        bar_w=90
        # bg pill
        pill=pygame.Surface((bar_w+4,30),pygame.SRCALPHA)
        pill.fill((*bg,int(180*t)))
        pygame.draw.rect(pill,(*col,int(120*t)),(0,0,bar_w+4,30),2,border_radius=8)
        s.blit(pill,(bx-2,by-2))
        # decay bar
        pygame.draw.rect(s,(30,30,30),(bx,by+22,bar_w,4),border_radius=2)
        bar_col=(int(255*(1-t*0.5)),int(200*t),int(50*t))
        pygame.draw.rect(s,bar_col,(bx,by+22,int(bar_w*t),4),border_radius=2)
        # multiplier label
        pulse_boost=int(math.sin(self.pulse)*25)
        r,g,b=col
        pc=(min(255,r+pulse_boost),min(255,g+pulse_boost),min(255,b+pulse_boost))
        sz=int(30*self.pop_scale) if self.pop_scale>1.02 else 30
        f=pygame.font.Font(None,max(10,sz))
        lbl=f.render(f"x{self.mult}",True,pc)
        lbl.set_alpha(min(255,int(255*t+80)))
        s.blit(lbl,(bx,by))
        cnt=tiny_font.render(f"{self.combo} hits",True,(180,180,180))
        cnt.set_alpha(int(200*t))
        s.blit(cnt,(bx+38,by+6))

        # -- big center popup on tier change --
        if self.center_timer>0:
            ct=self.center_timer/55
            # glow bg
            gw=int(260*ct); gh=int(80*ct)
            if gw>10 and gh>10:
                gs=pygame.Surface((gw,gh),pygame.SRCALPHA)
                r,g,b=self.center_col
                gs.fill((r//4,g//4,b//4,int(180*ct)))
                pygame.draw.rect(gs,(r,g,b,int(200*ct)),(0,0,gw,gh),3,border_radius=16)
                s.blit(gs,(WIDTH//2-gw//2,HEIGHT//2-gh//2-30))
            # text with scale pop
            scale=1.0+(1-ct)*0.8
            csz=max(10,int(54*scale))
            cf=pygame.font.Font(None,csz)
            # shadow
            shd=cf.render(self.center_text,True,(0,0,0))
            shd.set_alpha(int(180*ct))
            s.blit(shd,(WIDTH//2-shd.get_width()//2+3,HEIGHT//2-shd.get_height()//2-28))
            # main
            cm=cf.render(self.center_text,True,self.center_col)
            cm.set_alpha(int(255*ct))
            s.blit(cm,(WIDTH//2-cm.get_width()//2,HEIGHT//2-cm.get_height()//2-30))
            # sub
            sub=small_font.render(f"x{self.mult} MULTIPLIER  ({self.combo} hits)",True,self.center_col)
            sub.set_alpha(int(200*ct))
            s.blit(sub,(WIDTH//2-sub.get_width()//2,HEIGHT//2+16))

class LevelUpScreen:
    """Pilot level-up stat selection screen"""
    CHOICES=[
        ("atk","FIREPOWER +8%","Bullet dmg & score bonus",(255,80,80),">>"),
        ("spd","AGILITY  +8%","Move speed increase",     (80,255,120),">>"),
        ("def","ARMOR    +8%","Damage reduction",         (80,180,255),">>"),
        ("luck","LUCK     +8%","Item drop rate up",       (255,220,50),">>"),
    ]
    def __init__(self,level):
        self.level=level; self.selected=0; self.done=False
        import random as _r
        self.options=_r.sample(self.CHOICES,3)
        self.anim=0
    def update(self):
        self.anim+=1
    def handle_key(self,key):
        if key==pygame.K_UP:   self.selected=max(0,self.selected-1)
        elif key==pygame.K_DOWN: self.selected=min(len(self.options)-1,self.selected+1)
        elif key in (pygame.K_RETURN,pygame.K_KP_ENTER,pygame.K_SPACE):
            self._pick(self.selected); self.done=True
    def handle_tap(self,pos):
        for i in range(len(self.options)):
            y=HEIGHT//2-50+i*80
            if y-10<=pos[1]<=y+60:
                if self.selected==i: self._pick(i); self.done=True
                else: self.selected=i
    def _pick(self,i):
        key=self.options[i][0]
        stats.upgrades[key]=min(5,stats.upgrades.get(key,0)+1)
    def draw(self,s):
        ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); ov.fill((0,0,20,220)); s.blit(ov,(0,0))
        # title
        pulse=abs(math.sin(self.anim*0.06))*30
        tc=big_font.render(f"LEVEL UP!  Lv.{self.level}",True,(255,int(200+pulse),50))
        s.blit(tc,(WIDTH//2-tc.get_width()//2,HEIGHT//2-140))
        sub=small_font.render("Choose a permanent upgrade:",True,(180,180,220))
        s.blit(sub,(WIDTH//2-sub.get_width()//2,HEIGHT//2-100))
        for i,(key,name,desc,col,icon) in enumerate(self.options):
            y=HEIGHT//2-50+i*80
            sel=(i==self.selected)
            panel=pygame.Surface((WIDTH-48,66),pygame.SRCALPHA)
            if sel:
                panel.fill((*col,50))
                pygame.draw.rect(panel,(*col,200),(0,0,WIDTH-48,66),2,border_radius=10)
            else:
                panel.fill((20,20,50,160))
                pygame.draw.rect(panel,(60,60,80,140),(0,0,WIDTH-48,66),1,border_radius=10)
            s.blit(panel,(24,y))
            cur=stats.upgrades.get(key,0)
            nl=font.render(name,True,col if sel else WHITE)
            s.blit(nl,(44,y+8))
            dl=tiny_font.render(desc,True,(160,160,200))
            s.blit(dl,(44,y+30))
            # pip bar
            for p in range(5):
                px=WIDTH-80+p*12; py=y+22
                pygame.draw.circle(s,col if p<cur else (50,50,60),(px,py),4)
        hint=tiny_font.render("UP/DOWN: Select   ENTER/Tap: Choose",True,(100,100,140))
        s.blit(hint,(WIDTH//2-hint.get_width()//2,HEIGHT-20))

class FormationBonus:
    """Formation bonus - icon when formation intact, bonus if cleared intact"""
    def __init__(self):
        self.active=False; self.start_count=0; self.timer=0
        self.pulse=0.0; self.claimed=False
    def start(self,count):
        self.active=True; self.start_count=count
        self.timer=0; self.claimed=False
    def update(self,enemy_count,all_descended):
        self.pulse=(self.pulse+0.1)%(math.pi*2)
        if not self.active: return 0
        if not all_descended: return 0
        self.timer+=1
        if enemy_count==0 and not self.claimed:
            self.claimed=True; self.active=False
            return self.start_count*300
        return 0
    def draw(self,s,enemy_count):
        if not self.active or self.start_count==0: return
        ratio=enemy_count/max(1,self.start_count)
        if ratio<0.5: return
        pulse_a=int(160+math.sin(self.pulse)*60)
        lbl=tiny_font.render(f"FORMATION INTACT  {int(ratio*100)}%  BONUS READY!",True,(255,220,50))
        lbl.set_alpha(pulse_a)
        s.blit(lbl,(WIDTH//2-lbl.get_width()//2,HEIGHT-30))

class Coin:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x-8, y-8, 16, 16)
        self.vy = 1.5
        self.life = 300
        self.value = random.choice([10, 50, 100, 500])
        self.pulse = 0
    def update(self):
        self.rect.y += self.vy
        self.pulse += 0.1
        self.life -= 1
        return self.rect.top < HEIGHT + 20 and self.life > 0
    def draw(self, s):
        r = int(8 + math.sin(self.pulse) * 2)
        pygame.draw.circle(s, GOLD, self.rect.center, r)
        pygame.draw.circle(s, WHITE, self.rect.center, r, 1)


# ============================================================
# POWERUP
# ============================================================
class PowerUp:
    TYPES=["double","speed","life","shield","bomb","laser","missile","plasma","drone","timeslow","ally"]
    COLORS={"double":CYAN,"speed":YELLOW,"life":RED,"shield":(0,255,200),"bomb":(255,50,50),
            "laser":(180,80,255),"missile":(255,140,0),"plasma":(0,255,150),"drone":(200,200,0),
            "timeslow":(100,180,255),"ally":(255,220,80)}
    ICONS={}
    @classmethod
    def load_icons(cls):
        for pt in cls.TYPES:
            p=os.path.join(IMG_DIR,f"powerup_{pt}.png")
            if os.path.exists(p):
                try: img=pygame.image.load(p).convert_alpha(); cls.ICONS[pt]=pygame.transform.scale(img,(24,24))
                except: cls.ICONS[pt]=None
            else: cls.ICONS[pt]=None
    def __init__(self,x,y,ptype=None):
        self.type=ptype or random.choice(self.TYPES)
        self.rect=pygame.Rect(x-12,y,24,24)
        self.color=self.COLORS[self.type]; self.vy=1.2
        self.bob=random.uniform(0,math.pi*2); self.pulse=0
        self.icon=self.ICONS.get(self.type)
    def update(self):
        self.rect.y+=self.vy; self.bob+=0.1; self.pulse=(self.pulse+0.15)%(math.pi*2)
        return self.rect.top<HEIGHT+30
    def draw(self,s):
        gr=int(16+math.sin(self.pulse)*4); r,g,b=self.color
        gs=pygame.Surface((gr*2,gr*2),pygame.SRCALPHA)
        pygame.draw.circle(gs,(r,g,b,40),(gr,gr),gr)
        s.blit(gs,(self.rect.centerx-gr,self.rect.centery-gr))
        if self.icon: s.blit(self.icon,self.rect)
        else:
            pygame.draw.rect(s,self.color,self.rect,border_radius=5)
            pygame.draw.rect(s,WHITE,self.rect,1,border_radius=5)
            lbl=tiny_font.render(self.type[:3].upper(),True,WHITE)
            s.blit(lbl,lbl.get_rect(center=self.rect.center))

class Missile:
    """Player homing missile"""
    def __init__(self,x,y):
        self.x=float(x); self.y=float(y)
        self.vx=0.0; self.vy=-5.0
        self.life=200; self.trail=[]
        self.target=None
    def update(self,enemies):
        # track nearest enemy
        if self.target is None or self.target not in enemies:
            best=None; best_dist=9999
            for e in enemies:
                d=math.hypot(e.rect.centerx-self.x,e.rect.centery-self.y)
                if d<best_dist: best_dist=d; best=e
            self.target=best
        if self.target:
            dx=self.target.rect.centerx-self.x
            dy=self.target.rect.centery-self.y
            dist=max(1,math.hypot(dx,dy))
            ax=dx/dist*0.5; ay=dy/dist*0.5
            self.vx+=ax; self.vy+=ay
            spd=math.hypot(self.vx,self.vy)
            if spd>6: self.vx=self.vx/spd*6; self.vy=self.vy/spd*6
        self.trail.append((int(self.x),int(self.y)))
        if len(self.trail)>12: self.trail.pop(0)
        self.x+=self.vx; self.y+=self.vy; self.life-=1
        rect=pygame.Rect(int(self.x)-5,int(self.y)-5,10,10)
        return self.life>0 and self.y>-20, rect
    def draw(self,s):
        for i,pos in enumerate(self.trail):
            a=int(200*i/max(1,len(self.trail)))
            r=max(1,3*i//max(1,len(self.trail)))
            ts=pygame.Surface((r*2+2,r*2+2),pygame.SRCALPHA)
            pygame.draw.circle(ts,(255,120,0,a),(r+1,r+1),r)
            s.blit(ts,(pos[0]-r-1,pos[1]-r-1))
        pygame.draw.circle(s,(255,220,80),(int(self.x),int(self.y)),5)
        pygame.draw.circle(s,(255,255,255),(int(self.x),int(self.y)),3)

# ============================================================
# LASER BEAM
# ============================================================
class Laser:
    def __init__(self,x): self.x=x; self.life=18; self.width=6
    def update(self): self.life-=1; return self.life>0
    def draw(self,s):
        w=self.width+(18-self.life); a=int(255*self.life/18)
        surf=pygame.Surface((w*2,HEIGHT),pygame.SRCALPHA)
        pygame.draw.rect(surf,(180,80,255,a),(0,0,w*2,HEIGHT))
        pygame.draw.rect(surf,(255,200,255,min(255,a+80)),(w//2,0,w,HEIGHT))
        s.blit(surf,(self.x-w,0))

class PlasmaOrb:
    """Plasma orb - slow advance, area damage"""
    def __init__(self,x,y):
        self.x=float(x); self.y=float(y); self.vy=-2.5; self.life=160
        self.pulse=0; self.radius=18
    def update(self):
        self.y+=self.vy; self.pulse+=0.2; self.life-=1
        rect=pygame.Rect(int(self.x)-self.radius,int(self.y)-self.radius,self.radius*2,self.radius*2)
        return self.life>0 and self.y>-50, rect
    def draw(self,s):
        r=self.radius+int(math.sin(self.pulse)*3)
        ps=pygame.Surface((r*2+10,r*2+10),pygame.SRCALPHA)
        for i,a in [(r+4,30),(r,70),(r-4,120),(r-8,200)]:
            if i>0: pygame.draw.circle(ps,(0,255,160,a),(r+5,r+5),i)
        pygame.draw.circle(ps,(200,255,255,240),(r+5,r+5),5)
        s.blit(ps,(int(self.x)-r-5,int(self.y)-r-5))


# ============================================================
# SHIP DRAWING UTILITIES
# ============================================================
def draw_ship_mk1(surface,cx,cy,w,h,col,engine_flicker=0):
    r,g,b=col
    if engine_flicker>0:
        eg=pygame.Surface((w,20),pygame.SRCALPHA)
        pygame.draw.ellipse(eg,(r//2,g//2,min(255,b+100),engine_flicker),(0,0,w,20))
        surface.blit(eg,(cx-w//2,cy+h//2-4))
    pygame.draw.polygon(surface,col,[(cx,cy-h//2+2),(cx+w//2,cy+h//2-2),(cx-w//2,cy+h//2-2)])
    pygame.draw.polygon(surface,(r//2,g//2,b//2),[(cx-w//2,cy+h//2-2),(cx-w//2-10,cy+h//2+4),(cx-4,cy+4)])
    pygame.draw.polygon(surface,(r//2,g//2,b//2),[(cx+w//2,cy+h//2-2),(cx+w//2+10,cy+h//2+4),(cx+4,cy+4)])
    pygame.draw.rect(surface,(min(255,r+40),min(255,g+40),min(255,b+40)),(cx-5,cy+h//2-4,10,6),border_radius=2)
    pygame.draw.ellipse(surface,(min(255,r+80),min(255,g+120),255),(cx-5,cy-h//4,10,h//3))
    pygame.draw.polygon(surface,WHITE,[(cx,cy-h//2+2),(cx+w//2,cy+h//2-2),(cx-w//2,cy+h//2-2)],1)

def draw_ship_mk2(surface,cx,cy,w,h,col,engine_flicker=0):
    r,g,b=col
    for ex in [-10,10]:
        eg=pygame.Surface((14,22),pygame.SRCALPHA)
        pygame.draw.ellipse(eg,(r//3,g//3,min(255,b+120),max(0,engine_flicker)),(0,0,14,22))
        surface.blit(eg,(cx+ex-7,cy+h//2-6))
    body=[(cx,cy-h//2),(cx+8,cy-h//4),(cx+10,cy+h//4),(cx+6,cy+h//2),(cx-6,cy+h//2),(cx-10,cy+h//4),(cx-8,cy-h//4)]
    pygame.draw.polygon(surface,col,body)
    pygame.draw.polygon(surface,(r//2,g//2+20,b//2),[(cx-8,cy),(cx-w//2-6,cy+h//4+4),(cx-w//2+2,cy+h//2),(cx-6,cy+h//3)])
    pygame.draw.polygon(surface,(r//2,g//2+20,b//2),[(cx+8,cy),(cx+w//2+6,cy+h//4+4),(cx+w//2-2,cy+h//2),(cx+6,cy+h//3)])
    for cx2 in [cx-12,cx+12]:
        pygame.draw.rect(surface,(min(255,r+60),min(255,g+60),255),(cx2-2,cy-h//2+2,4,h//3),border_radius=1)
    pygame.draw.ellipse(surface,(100,220,255),(cx-7,cy-h//2+4,14,h//3+2))
    pygame.draw.ellipse(surface,(200,240,255),(cx-4,cy-h//2+6,8,h//4))
    for ex in [-10,10]:
        pygame.draw.rect(surface,(80,80,120),(cx+ex-5,cy+h//2-6,10,8),border_radius=3)
    pygame.draw.polygon(surface,WHITE,body,1)

def draw_ship_mk3(surface,cx,cy,w,h,col,engine_flicker=0,tick=0):
    r,g,b=col
    pulse=abs(math.sin(tick*0.08))*40
    gc=(min(255,r+int(pulse)),min(255,g+int(pulse)),min(255,b+int(pulse)))
    for ex in [-18,-9,0,9,18]:
        eg=pygame.Surface((12,26),pygame.SRCALPHA)
        pygame.draw.ellipse(eg,(r//4,g//4,min(255,b+150),min(200,engine_flicker+40)),(0,0,12,26))
        surface.blit(eg,(cx+ex-6,cy+h//2-8))
    pygame.draw.polygon(surface,(r//3,g//3,b//2+40),[(cx-10,cy-h//6),(cx-w//2-14,cy+h//2+4),(cx-w//2+4,cy+h//2-2),(cx-8,cy+h//6)])
    pygame.draw.polygon(surface,(r//3,g//3,b//2+40),[(cx+10,cy-h//6),(cx+w//2+14,cy+h//2+4),(cx+w//2-4,cy+h//2-2),(cx+8,cy+h//6)])
    pygame.draw.polygon(surface,(r//2,g//2+20,b//2+60),[(cx-8,cy-h//3),(cx-w//3,cy+h//4),(cx-6,cy+h//2-2),(cx-4,cy)])
    pygame.draw.polygon(surface,(r//2,g//2+20,b//2+60),[(cx+8,cy-h//3),(cx+w//3,cy+h//4),(cx+6,cy+h//2-2),(cx+4,cy)])
    body=[(cx,cy-h//2-4),(cx+10,cy-h//4),(cx+12,cy+h//4),(cx+7,cy+h//2),(cx-7,cy+h//2),(cx-12,cy+h//4),(cx-10,cy-h//4)]
    pygame.draw.polygon(surface,col,body)
    cr=int(8+math.sin(tick*0.1)*2)
    cs=pygame.Surface((cr*2+4,cr*2+4),pygame.SRCALPHA)
    pygame.draw.circle(cs,(*gc,180),(cr+2,cr+2),cr)
    pygame.draw.circle(cs,(255,255,255,220),(cr+2,cr+2),cr//2)
    surface.blit(cs,(cx-cr-2,cy-cr//2-2))
    for cx2 in [cx-14,cx,cx+14]:
        pygame.draw.rect(surface,gc,(cx2-2,cy-h//2-6,4,h//3+4),border_radius=1)
        pygame.draw.rect(surface,(200,230,255),(cx2-1,cy-h//2-6,2,h//4),border_radius=1)
    pygame.draw.ellipse(surface,(80,200,255),(cx-8,cy-h//2+2,16,h//3))
    pygame.draw.ellipse(surface,(200,240,255),(cx-4,cy-h//2+5,8,h//5))
    for wx,wy in [(cx-w//2-14,cy+h//2+4),(cx+w//2+14,cy+h//2+4)]:
        pygame.draw.circle(surface,(255,100,100),(wx,wy),3)
    pygame.draw.polygon(surface,WHITE,body,1)

def draw_ally_phoenix(surface,cx,cy,w,h,tick=0,engine_flicker=0):
    """Phoenix - elegant ally ship, gold/white"""
    pulse=math.sin(tick*0.09)
    gc=(255,int(200+pulse*30),int(80+pulse*20))
    wc=(220,240,255)
    for ex,ea in [(-12,160),(-4,200),(4,200),(12,160)]:
        eg=pygame.Surface((10,30),pygame.SRCALPHA)
        pygame.draw.ellipse(eg,(*gc,min(200,engine_flicker+30)),(0,0,10,30))
        surface.blit(eg,(cx+ex-5,cy+h//2-6))
    pygame.draw.polygon(surface,(180,140,60),[(cx-6,cy-h//4),(cx-w//2-10,cy+h//3),(cx-w//2+4,cy+h//2+2),(cx-10,cy+h//4),(cx-6,cy)])
    pygame.draw.polygon(surface,(180,140,60),[(cx+6,cy-h//4),(cx+w//2+10,cy+h//3),(cx+w//2-4,cy+h//2+2),(cx+10,cy+h//4),(cx+6,cy)])
    pygame.draw.polygon(surface,(220,180,80),[(cx-6,cy-h//3),(cx-w//3,cy+h//5),(cx-5,cy+h//3),(cx-3,cy)])
    pygame.draw.polygon(surface,(220,180,80),[(cx+6,cy-h//3),(cx+w//3,cy+h//5),(cx+5,cy+h//3),(cx+3,cy)])
    body=[(cx,cy-h//2-4),(cx+9,cy-h//4),(cx+11,cy+h//5),(cx+7,cy+h//2),(cx-7,cy+h//2),(cx-11,cy+h//5),(cx-9,cy-h//4)]
    pygame.draw.polygon(surface,wc,body)
    pygame.draw.polygon(surface,gc,[(cx-4,cy-h//2-2),(cx+4,cy-h//2-2),(cx+6,cy+h//3),(cx-6,cy+h//3)],2)
    for cx2 in [cx-10,cx+10]:
        pygame.draw.rect(surface,gc,(cx2-2,cy-h//2,4,h//3+2),border_radius=1)
    pygame.draw.ellipse(surface,(180,100,255),(cx-7,cy-h//2+3,14,h//3))
    pygame.draw.ellipse(surface,(230,200,255),(cx-3,cy-h//2+6,6,h//5))
    cr=int(5+pulse*2)
    cs=pygame.Surface((cr*2+4,cr*2+4),pygame.SRCALPHA)
    pygame.draw.circle(cs,(*gc,200),(cr+2,cr+2),cr)
    pygame.draw.circle(cs,(255,255,255,240),(cr+2,cr+2),max(1,cr//2))
    surface.blit(cs,(cx-cr-2,cy))
    for wx,wy in [(cx-w//2-10,cy+h//3),(cx+w//2+10,cy+h//3)]:
        pygame.draw.circle(surface,gc,(wx,wy),4)
        pygame.draw.circle(surface,WHITE,(wx,wy),2)
    for ex in [-12,-4,4,12]:
        pygame.draw.rect(surface,(100,80,40),(cx+ex-3,cy+h//2-2,6,6),border_radius=2)
    pygame.draw.polygon(surface,(255,220,120),body,1)

SHIP_UPGRADE_NAMES=["Mk.I  Starfighter","Mk.II  Assault","Mk.III  Vanguard"]
SHIP_UPGRADE_COLORS=[(0,180,255),(80,255,160),(200,100,255)]

# ============================================================
# PLAYER
# ============================================================
class Player:
    def __init__(self):
        self.rect=pygame.Rect(WIDTH//2-20,HEIGHT-90,40,40)
        self.speed=5; self.lives=3; self.score=0
        self.combo=0; self.multiplier=1; self.invincible=0
        self.shoot_cooldown=0; self.double_fighter=False; self.double_timer=0
        self.shield_active=False; self.shield_timer=0; self.speed_boost=0
        self.laser_active=False; self.laser_timer=0
        self.special_gauge=0; self.special_ready=False
        self.kill_streak=0; self.streak_timer=0
        self.message=""; self.message_timer=0; self.message_style='normal'
        self.frame_idx=0; self.frame_t=0; self.shield_pulse=0
        self.frames=[]; self.life_icon=None; self._load()
        # new powerups
        self.missile_ammo=0; self.missile_cd=0
        self.plasma_ammo=0; self.plasma_cd=0
        self.drone_active=False; self.drone_timer=0; self.drone_angle=0.0
        self.timeslow_active=False; self.timeslow_timer=0
        # pilot XP flash
        self.xp_flash=0; self.xp_flash_amt=0
        # ship upgrade
        self.ship_level=0   # 0=Mk.I, 1=Mk.II, 2=Mk.III
        self.ally_active=False; self.ally_timer=0
        self.ally_x=0.0; self.ally_y=0.0; self.ally_shoot_cd=0
        # dash
        self.dash_cd=0; self.dash_timer=0
        self.dash_dx=0.0; self.dash_dy=0.0
        self.dash_trail=[]
    def _load(self):
        for n in ("player1.png","player2.png"):
            p=os.path.join(IMG_DIR,n)
            if os.path.exists(p):
                try: img=pygame.image.load(p).convert_alpha(); self.frames.append(pygame.transform.scale(img,(40,40)))
                except: pass
        lp=os.path.join(IMG_DIR,"player_life.png")
        if os.path.exists(lp):
            try: img=pygame.image.load(lp).convert_alpha(); self.life_icon=pygame.transform.scale(img,(22,22))
            except: pass
    def _frame(self):
        self.frame_t+=1
        if self.frame_t>=8: self.frame_t=0; self.frame_idx=(self.frame_idx+1)%max(1,len(self.frames))
        return self.frames[self.frame_idx%len(self.frames)] if self.frames else None
    def try_dash(self,dx,dy):
        """Double-tap dash - brief invincible burst in movement direction"""
        if self.dash_cd>0: return False
        spd=math.hypot(dx,dy)
        if spd<0.2: dx,dy=0,-1  # dash up if no direction
        else: dx,dy=dx/spd,dy/spd
        self.dash_dx=dx; self.dash_dy=dy
        self.dash_timer=12      # dash duration frames
        self.dash_cd=45         # cooldown
        self.invincible=max(self.invincible,14)  # brief invincibility
        return True

    def move(self,dx,dy):
        spd=self.speed*(1.0+stats.upgrade_bonus("spd"))*(1.5 if self.speed_boost>0 else 1.0)
        mag=math.hypot(dx,dy)
        if mag>1.0: dx/=mag; dy/=mag
        self.rect.x=max(0,min(WIDTH-self.rect.w, self.rect.x+int(dx*spd)))
        self.rect.y=max(HEIGHT//3,min(HEIGHT-self.rect.h-58, self.rect.y+int(dy*spd)))
    def shoot(self):
        if self.shoot_cooldown>0: return [],None,None,None
        self.shoot_cooldown=9 if self.laser_active else 11
        sounds.play("shoot")
        cx=self.rect.centerx
        if self.laser_active: return [],Laser(cx),None,None
        # base bullets
        bullets=[pygame.Rect(cx-2,self.rect.top,4,14)]
        if self.double_fighter:
            bullets.append(pygame.Rect(self.rect.left+4,self.rect.top+8,4,14))
            bullets.append(pygame.Rect(self.rect.right-8,self.rect.top+8,4,14))
        # missile fires simultaneously with bullets (every 3rd shot)
        missile=None
        if self.missile_ammo>0 and self.missile_cd==0:
            self.missile_ammo-=1; self.missile_cd=18  # tighter cd - fires more often
            missile=Missile(cx,self.rect.top)
        elif self.missile_ammo>0 and self.missile_cd>0:
            self.missile_cd=max(0,self.missile_cd-1)
        # plasma
        plasma=None
        if self.plasma_ammo>0 and self.plasma_cd==0:
            self.plasma_ammo-=1; self.plasma_cd=50
            plasma=PlasmaOrb(cx,self.rect.top-10)
        return bullets,None,missile,plasma

    def ally_fire(self,enemies):
        """Phoenix ally shoots homing bullet + small missile burst"""
        if not self.ally_active: return [],None
        if self.ally_shoot_cd>0: return [],None
        self.ally_shoot_cd=22
        ax=int(self.ally_x); ay=int(self.ally_y)
        # 3-way spread bullets from Phoenix
        ally_bullets=[]
        for ang_off in [-0.15, 0, 0.15]:
            ally_bullets.append({
                "rect": pygame.Rect(ax-2, ay-19, 4, 12),
                "vx": math.sin(ang_off)*3,
                "vy": -8,
                "col": (255,220,80),
            })
        # every 4th shot fire a mini homing missile
        mini=None
        if (self.frame_t//22)%4==0 and enemies:
            mini=Missile(ax,ay-19)
            mini.vx=0; mini.vy=-6
        return ally_bullets, mini
    def hit(self):
        if self.invincible>0: return False
        if self.shield_active:
            self.shield_active=False; self.shield_timer=0
            self.show_message("Shield Broken!"); sounds.play("explosion"); return False
        self.lives-=1; self.invincible=90; self.combo=0; self.multiplier=1; self.kill_streak=0
        sounds.play("explosion"); return True
    def add_powerup(self,ptype):
        sounds.play("powerup")
        if   ptype=="double": self.double_fighter=True; self.double_timer=700; self.show_message("DOUBLE FIGHTER!","bounce")
        elif ptype=="speed":  self.speed_boost=600;     self.show_message("TURBO BOOST!","bounce")
        elif ptype=="life" and self.lives<5: self.lives+=1; self.show_message("EXTRA LIFE!","bounce")
        elif ptype=="shield": self.shield_active=True;  self.shield_timer=900; self.show_message("SHIELDS UP!","bounce")
        elif ptype=="bomb":   self.show_message("BOMB AWAY!","shake"); return "bomb"
        elif ptype=="laser":  self.laser_active=True;   self.laser_timer=480; self.show_message("LASER LOCKED!","bounce")
        elif ptype=="missile": self.missile_ammo=min(self.missile_ammo+5,20); self.show_message("MISSILES x5!","bounce")
        elif ptype=="plasma": self.plasma_ammo=min(self.plasma_ammo+3,10); self.show_message("PLASMA x3!","bounce")
        elif ptype=="drone":  self.drone_active=True; self.drone_timer=800; self.show_message("DRONE DEPLOYED!","bounce")
        elif ptype=="timeslow": self.timeslow_active=True; self.timeslow_timer=300; self.show_message("TIME SLOW!","bounce")
        elif ptype=="ally":
            self.ally_active=True; self.ally_timer=1200
            self.ally_x=float(self.rect.centerx+55); self.ally_y=float(self.rect.centery)
            self.show_message("PHOENIX JOINS!","streak")
        return None
    def add_kill(self):
        self.kill_streak+=1; self.streak_timer=90
        # XP gain
        xp_gain=int(10*(1.0+stats.upgrade_bonus("atk")))
        leveled=stats.add_xp(xp_gain)
        self.xp_flash=40; self.xp_flash_amt=xp_gain
        STREAK_MSGS=[
            (5,  500,  "KILLING SPREE!",   'streak'),
            (10, 2000, "DOMINATING!!",     'streak'),
            (15, 5000, "UNSTOPPABLE!!!",   'streak'),
            (20, 10000,"GODLIKE!!!!",      'streak'),
            (25, 20000,"LEGENDARY!!!!!",   'streak'),
            (30, 50000,"BEYOND GODLIKE!",'streak'),
        ]
        for threshold,bonus,msg,style in STREAK_MSGS:
            if self.kill_streak==threshold:
                self.score+=bonus; self.show_message(msg,style); break
        return leveled  # True if leveled up
        self.special_gauge=min(100,self.special_gauge+0.5); self.special_ready=self.special_gauge>=100
    def charge_special(self):
        self.special_gauge=min(100,self.special_gauge+0.5); self.special_ready=self.special_gauge>=100
    def show_message(self,msg,style='normal'): self.message=msg; self.message_timer=110; self.message_style=style
    def update(self):
        if self.shoot_cooldown>0: self.shoot_cooldown-=1
        if self.missile_cd>0: self.missile_cd-=1
        if self.plasma_cd>0: self.plasma_cd-=1
        if self.invincible>0: self.invincible-=1
        if self.double_timer>0:
            self.double_timer-=1
            if self.double_timer==0: self.double_fighter=False
        if self.speed_boost>0: self.speed_boost-=1
        if self.shield_timer>0:
            self.shield_timer-=1
            if self.shield_timer==0: self.shield_active=False
        if self.laser_timer>0:
            self.laser_timer-=1
            if self.laser_timer==0: self.laser_active=False
        if self.drone_timer>0:
            self.drone_timer-=1; self.drone_angle+=0.08
            if self.drone_timer==0: self.drone_active=False
        if self.timeslow_timer>0:
            self.timeslow_timer-=1
            if self.timeslow_timer==0: self.timeslow_active=False
        # dash update
        if self.dash_cd>0: self.dash_cd-=1
        if self.dash_timer>0:
            self.dash_timer-=1
            spd=18
            self.rect.x=max(0,min(WIDTH-self.rect.w,self.rect.x+int(self.dash_dx*spd)))
            self.rect.y=max(0,min(HEIGHT-self.rect.h-58,self.rect.y+int(self.dash_dy*spd)))
            # add afterimage trail
            self.dash_trail.append([self.rect.centerx,self.rect.centery,180])
        # fade trail
        self.dash_trail=[[x,y,max(0,a-22)] for x,y,a in self.dash_trail if a>0]
        # ally Phoenix update
        if self.ally_active:
            self.ally_timer-=1
            if self.ally_timer<=0: self.ally_active=False
            # glide to right of player
            tx=self.rect.centerx+55; ty=self.rect.centery+10
            self.ally_x+=(tx-self.ally_x)*0.08
            self.ally_y+=(ty-self.ally_y)*0.08
            if self.ally_shoot_cd>0: self.ally_shoot_cd-=1
        # ship upgrade by pilot level
        lvl=stats.pilot_level
        self.ship_level=2 if lvl>=10 else (1 if lvl>=5 else 0)
        if self.streak_timer>0:
            self.streak_timer-=1
            if self.streak_timer==0: self.kill_streak=0
        if self.message_timer>0: self.message_timer-=1
        self.shield_pulse=(self.shield_pulse+0.1)%(math.pi*2)

    def draw(self,surface):
        # dash afterimage trail
        col=get_skin_col()
        for tx,ty,ta in self.dash_trail:
            ts=pygame.Surface((self.rect.w,self.rect.h),pygame.SRCALPHA)
            pygame.draw.polygon(ts,(*col,ta),
                [(self.rect.w//2,4),(self.rect.w-4,self.rect.h-4),(4,self.rect.h-4)])
            surface.blit(ts,(tx-self.rect.w//2,ty-self.rect.h//2))
        vis=self.invincible==0 or (self.invincible//4)%2
        if vis:
            frm=self._frame()
            if frm:
                surface.blit(frm,self.rect)
            else:
                cx=self.rect.centerx; cy=self.rect.centery
                w=self.rect.width;    h=self.rect.height
                ef=int(100+math.sin(self.frame_t*0.2)*40) if self.frame_t else 100
                col=get_skin_col()   # use active skin color
                if self.ship_level==0:
                    draw_ship_mk1(surface,cx,cy,w,h,col,ef)
                elif self.ship_level==1:
                    draw_ship_mk2(surface,cx,cy,w+6,h+4,col,ef)
                else:
                    draw_ship_mk3(surface,cx,cy,w+10,h+6,col,ef,self.frame_t)
        # ally Phoenix
        if self.ally_active:
            ax=int(self.ally_x); ay=int(self.ally_y)
            draw_ally_phoenix(surface,ax,ay,38,38,self.frame_t,
                              int(80+math.sin(self.frame_t*0.15)*40))
            # ally laser line every 30 frames
            if (self.frame_t//30)%2==0:
                pygame.draw.line(surface,(255,220,80),(ax,ay-19),(ax,ay-80),2)
        if self.shield_active:
            r=int(28+math.sin(self.shield_pulse)*3)
            for i,a in [(r+4,30),(r,80),(r-2,160)]:
                ss=pygame.Surface((i*2+2,i*2+2),pygame.SRCALPHA)
                pygame.draw.circle(ss,(0,255,200,a),(i+1,i+1),i,2)
                surface.blit(ss,(self.rect.centerx-i-1,self.rect.centery-i-1))
        if self.laser_active:
            bw=36; ratio=self.laser_timer/480
            pygame.draw.rect(surface,GRAY,(self.rect.x+2,self.rect.bottom+2,bw,4))
            pygame.draw.rect(surface,(180,80,255),(self.rect.x+2,self.rect.bottom+2,int(bw*ratio),4))
        if self.double_fighter:
            gr=self.rect.copy(); gr.x-=28; gr.y+=5
            pts=[(gr.centerx,gr.top),(gr.right,gr.bottom-5),(gr.centerx+5,gr.centery+5),
                 (gr.centerx-5,gr.centery+5),(gr.left,gr.bottom-5)]
            pygame.draw.polygon(surface,(0,200,150),pts)
            pygame.draw.polygon(surface,WHITE,pts,1)
        if self.drone_active:
            da=self.drone_angle
            dx2=int(self.rect.centerx+math.cos(da)*38)
            dy2=int(self.rect.centery+math.sin(da)*30)
            pygame.draw.circle(surface,(200,200,0),(dx2,dy2),8)
            pygame.draw.circle(surface,(255,255,100),(dx2,dy2),5)
            pygame.draw.circle(surface,WHITE,(dx2,dy2),8,2)
            if (self.frame_t//10)%2==0:
                pygame.draw.line(surface,(255,255,0),(dx2,dy2),(dx2,dy2-20),2)
        if self.missile_ammo>0:
            ml=tiny_font.render(f"MSL:{self.missile_ammo}",True,ORANGE)
            surface.blit(ml,(self.rect.x,self.rect.y-16))
        if self.timeslow_active:
            ts_ratio=self.timeslow_timer/300
            ts=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
            ts.fill((100,150,255,int(20*ts_ratio)))
            surface.blit(ts,(0,0))
        # ship level badge + title
        lv_col=get_skin_col()
        lv_lbl=tiny_font.render(SHIP_UPGRADE_NAMES[min(self.ship_level,2)],True,lv_col)
        surface.blit(lv_lbl,(WIDTH//2-lv_lbl.get_width()//2,HEIGHT-28))
        if stats.active_title:
            ti=next((t for t in TITLES if t["id"]==stats.active_title),None)
            if ti:
                tl=tiny_font.render(f"[ {ti['name']} ]",True,ti["col"])
                surface.blit(tl,(WIDTH//2-tl.get_width()//2,HEIGHT-16))
        # life icons
        pcol=(100,200,255)
        li=self._load_img("player_life.png",(22,22))
        for i in range(self.lives):
            if li: surface.blit(li,(WIDTH-30-i*28,60))
            else: pygame.draw.polygon(surface,pcol,[(WIDTH-22-i*22,68),(WIDTH-30-i*22,78),(WIDTH-14-i*22,78)])

    def _load_img(self,name,size):    #         
        p=os.path.join(IMG_DIR,name)
        if os.path.exists(p):
            try:
                img=pygame.image.load(p).convert_alpha()
                return pygame.transform.scale(img,size)
            except:
                pass
        return None

    def use_special(self):
        if not self.special_ready: return False
        self.special_gauge=0
        self.special_ready=False
        self.show_message("LIGHTNING CHAIN!",'streak')
        sounds.play("explosion")
        return True

# ============================================================
# ENEMY  (7 types)
# ============================================================
ENEMY_DEF = {
    "normal":   (1, RED,              30, 100,  ""),
    "fast":     (1, CYAN,             24, 120,  "fast"),
    "elite":    (2, PURPLE,           30, 200,  ""),
    "armored":  (3, GRAY,             32, 300,  ""),
    "splitter": (2, ORANGE,           28, 250,  "split"),
    "ghost":    (1, (160,160,255),    30, 180,  "ghost"),
    "bomber":   (2, PINK,             34, 280,  "bomb"),
    "zigzag":   (1, LIME,             26, 150,  "zigzag"),
    "spiral":   (2, (255,100,200),    28, 220,  "spiral"),
    "sniper":   (1, (200,255,100),    26, 240,  "zigzag"),
    # new types
    "mimic":    (2, (120,200,255),    28, 260,  "mimic"),   # copies player X position
    "shielded": (3, (80,180,255),     32, 350,  "shield"),  # frontal shield
    "swarm":    (1, (255,160,60),     20, 80,   "swarm"),   # tiny, 3 at once
    "assassin": (2, (200,50,200),     26, 300,  "assassin"),# fast + invisible + burst
}

class Enemy:
    FRAMES=[]
    @classmethod
    def load_frames(cls):
        cls.FRAMES=[]
        for n in ("enemy1.png","enemy2.png"):
            p=os.path.join(IMG_DIR,n)
            if os.path.exists(p):
                try: img=pygame.image.load(p).convert_alpha(); cls.FRAMES.append(pygame.transform.scale(img,(30,30)))
                except: pass

    def __init__(self,x,y,etype="normal",tier=0):
        self.etype=etype; self.tier=tier
        hp,col,sz,sc,beh=ENEMY_DEF.get(etype,(1,RED,30,100,""))
        # note
        hp_bonus  = tier // 3
        sz_bonus  = min(tier*1, 8)
        sc_mult   = 1 + tier * 0.2
        self.rect=pygame.Rect(x,y,sz+sz_bonus,sz+sz_bonus)
        self.color=col
        self.score_val=int(sc*sc_mult)
        self.behaviour=beh
        self.target_y=float(y); self.base_x=float(x); self.base_y=float(y)
        self.state="descending"; self.dive_timer=0
        self.frame_t=random.randint(0,16)
        self.hp=hp+hp_bonus; self.flash=0
        self.zz_dir=1
        # note
        self.speed_mult=1.0+tier*0.08

    def update(self,player_rect,slow=False):
        self.frame_t+=1
        spd_mult=0.4 if slow else 1.0
        if self.flash>0: self.flash-=1
        if self.state=="descending":
            dist=self.target_y-self.rect.y
            mv=max(1,min(3,int(dist//20)+1))
            self.rect.y+=int(mv*spd_mult+0.5)
            if self.rect.y>=self.target_y:
                self.rect.y=int(self.target_y); self.state="formation"; self.base_y=float(self.rect.y)
        elif self.state=="dive":
            self.dive_timer+=1
            duration=max(60,int(130/self.speed_mult))
            prog=min(1.0,self.dive_timer/duration)
            ease=prog*prog*(3-2*prog)
            tx=player_rect.centerx
            if self.behaviour=="zigzag":
                zz=math.sin(self.dive_timer*0.3*(1+self.tier*0.05))*70
                self.rect.x=int(self.base_x+(tx-self.base_x)*ease+zz)
            elif self.behaviour=="spiral":
                ang=self.dive_timer*0.12
                self.rect.x=int(self.base_x+(tx-self.base_x)*ease+math.cos(ang)*50*(1-ease))
            elif self.behaviour=="mimic":
                target_x=player_rect.centerx-self.rect.w//2
                self.base_x+=(target_x-self.base_x)*0.03*spd_mult
                self.rect.x=int(self.base_x+(tx-self.base_x)*ease)
            else:
                self.rect.x=int(self.base_x+(tx-self.base_x)*ease)
            self.rect.y=int(self.base_y+ease*420*spd_mult)
            if self.rect.top>HEIGHT+50:
                # clamp base_y back on screen before returning
                if self.base_y > HEIGHT*0.6:
                    self.base_y = random.randint(60, int(HEIGHT*0.45))
                self.rect.x=int(self.base_x)
                self.rect.y=int(self.base_y)
                self.rect.x=max(10,min(WIDTH-self.rect.w-10,self.rect.x))
                self.state="formation"; self.dive_timer=0
        if self.state=="formation":
            t=self.frame_t*0.06
            if self.behaviour=="fast":
                self.rect.x=int(self.base_x+math.sin(t)*14)
            elif self.behaviour=="ghost":
                self.rect.x=int(self.base_x+math.sin(t*0.5)*20)
            elif self.behaviour=="zigzag":
                self.rect.x=int(self.base_x+math.sin(t*0.7)*18)
                self.rect.y=int(self.base_y+math.cos(t*0.5)*8)
            elif self.behaviour=="bomb":
                self.rect.x=int(self.base_x+math.sin(t*0.4)*10)
            elif self.behaviour=="spiral":
                self.rect.x=int(self.base_x+math.sin(t*0.6)*22)
                self.rect.y=int(self.base_y+math.cos(t*0.4)*10)
            elif self.behaviour=="mimic":
                # slowly drift left/right based on sin
                self.rect.x=int(self.base_x+math.sin(t*0.3)*30)
            elif self.behaviour=="swarm":
                self.rect.x=int(self.base_x+math.sin(t*1.2+self.base_x)*10)
                self.rect.y=int(self.base_y+math.cos(t*0.9)*6)
            elif self.behaviour=="assassin":
                if (self.frame_t//20)%4==3:  # flicker in/out
                    pass
                else:
                    self.rect.x=int(self.base_x+math.sin(t*0.8)*16)

    def start_dive(self): self.state="dive"; self.dive_timer=0
    def take_hit(self): self.hp-=1; self.flash=6; return self.hp<=0

    def draw(self,surface):
        # assassin flicker
        if self.behaviour=="assassin" and (self.frame_t//20)%4==3: return
        # ghost flicker
        if self.behaviour=="ghost" and (self.frame_t//8)%2==1: return
        fi=(self.frame_t//16)%max(1,len(self.FRAMES))
        sz=self.rect.w; cx=self.rect.centerx; cy=self.rect.centery
        if self.FRAMES:
            base=self.FRAMES[min(fi,len(self.FRAMES)-1)]
            img=pygame.transform.scale(base,(sz,sz))
            tinted=img.copy()
            tc={"fast":(0,200,255,60),"elite":(180,0,255,60),"armored":(160,160,160,80),
                "splitter":(255,120,0,60),"ghost":(160,160,255,80),
                "bomber":(255,80,180,60),"zigzag":(100,255,0,60),
                "mimic":(120,200,255,80),"shielded":(80,180,255,80),
                "swarm":(255,160,60,80),"assassin":(200,50,200,80)}.get(self.etype)
            if tc: tinted.fill(tc,special_flags=pygame.BLEND_RGBA_ADD)
            if self.flash>0: tinted.fill((255,255,255,200),special_flags=pygame.BLEND_RGBA_ADD)
            surface.blit(tinted,self.rect)
        else:
            col=self.color if self.flash==0 else WHITE
            # type-specific shapes
            if self.behaviour=="mimic":
                # diamond shape
                pts=[(cx,cy-sz//2),(cx+sz//2,cy),(cx,cy+sz//2),(cx-sz//2,cy)]
                pygame.draw.polygon(surface,col,pts)
                pygame.draw.polygon(surface,WHITE,pts,1)
                pygame.draw.circle(surface,(200,240,255),(cx,cy),sz//5)
            elif self.behaviour=="shield":
                # hexagon with front shield
                pts=[(cx,cy-sz//2),(cx+sz//2,cy-sz//4),(cx+sz//2,cy+sz//4),
                     (cx,cy+sz//2),(cx-sz//2,cy+sz//4),(cx-sz//2,cy-sz//4)]
                pygame.draw.polygon(surface,col,pts)
                pygame.draw.polygon(surface,WHITE,pts,2)
                # shield bar on top
                pygame.draw.ellipse(surface,(80,180,255,),(cx-sz//2,cy-sz//2-4,sz,8))
                pygame.draw.ellipse(surface,(200,230,255),(cx-sz//2,cy-sz//2-4,sz,8),2)
            elif self.behaviour=="swarm":
                # tiny triangle swarm unit
                pygame.draw.polygon(surface,col,[(cx,cy-sz//2),(cx+sz//2,cy+sz//2),(cx-sz//2,cy+sz//2)])
                pygame.draw.polygon(surface,WHITE,[(cx,cy-sz//2),(cx+sz//2,cy+sz//2),(cx-sz//2,cy+sz//2)],1)
            elif self.behaviour=="assassin":
                # X-wing killer shape
                pygame.draw.polygon(surface,col,[(cx,cy-sz//2),(cx+sz//3,cy),(cx,cy+sz//4),(cx-sz//3,cy)])
                pygame.draw.line(surface,col,(cx-sz//2,cy-sz//4),(cx+sz//2,cy+sz//4),3)
                pygame.draw.line(surface,col,(cx+sz//2,cy-sz//4),(cx-sz//2,cy+sz//4),3)
                pygame.draw.circle(surface,(220,80,220),(cx,cy),sz//5)
            else:
                pygame.draw.rect(surface,col,self.rect,border_radius=4)
                pygame.draw.rect(surface,WHITE,self.rect,2,border_radius=4)
        if self.hp>1:
            for i in range(self.hp):
                pygame.draw.circle(surface,YELLOW,(self.rect.x+8+i*8,self.rect.y+3),3)

# ============================================================
# BOSS TYPES  (7 different bosses)
# ============================================================
class BossBase:
    def __init__(self,stage,name,hp,size,speed,col):
        self.name=name; self.stage=stage
        self.rect=pygame.Rect(WIDTH//2-size//2,-size-20,size,size)
        self.max_hp=hp; self.hp=hp; self.speed=speed; self.direction=1
        self.entering=True; self.bullets=[]; self.attack_timer=0
        self.phase=1; self.rage_flash=0; self.spread_timer=0
        self.color=col; self.pulse=0; self.size=size
        self.image=self._load_img()
        self.tractor_active=False; self.tractor_timer=0

    def _load_img(self):
        for fname in [f"boss_{self.name.lower().replace(' ','_').replace(' ii','2')}.png","boss.png"]:
            try:
                img=pygame.image.load(f"{IMG_DIR}/{fname}").convert_alpha()
                return pygame.transform.scale(img,(self.size,self.size))
            except: pass
        return None

    def _fire(self,px,py,spd,col=None,ang_offset=0):
        dx=px-self.rect.centerx; dy=py-self.rect.centery
        base=math.atan2(dy,dx)+ang_offset; dist=max(1,math.hypot(dx,dy))
        self.bullets.append({"rect":pygame.Rect(self.rect.centerx-4,self.rect.bottom,8,14),
                              "vx":math.cos(base)*spd,"vy":math.sin(base)*spd,
                              "col":col or (ORANGE if self.phase==1 else RED)})

    def _fire_spread(self,px,py,count,spd,spread=math.pi/5):
        dx=px-self.rect.centerx; dy=py-self.rect.centery
        base=math.atan2(dy,dx)
        for i in range(count):
            ang=base-spread/2+spread*i/max(1,count-1)
            self.bullets.append({"rect":pygame.Rect(self.rect.centerx-4,self.rect.bottom,8,14),
                                  "vx":math.cos(ang)*spd,"vy":math.sin(ang)*spd,
                                  "col":ORANGE if self.phase==1 else RED})

    def _fire_spiral(self,spd,offset=0):
        """Spiral bullet pattern"""
        if not hasattr(self,'spiral_ang'): self.spiral_ang=0.0
        self.spiral_ang+=0.45
        for i in range(3):
            ang=self.spiral_ang+i*math.pi*2/3+offset
            self.bullets.append({"rect":pygame.Rect(self.rect.centerx-4,self.rect.centery,8,14),
                                  "vx":math.cos(ang)*spd,"vy":math.sin(ang)*spd,
                                  "col":(255,80,200)})

    def _fire_cross(self,spd):
        """Cross pattern - 4 directions"""
        for ang in [0,math.pi/2,math.pi,math.pi*3/2]:
            self.bullets.append({"rect":pygame.Rect(self.rect.centerx-4,self.rect.centery,8,14),
                                  "vx":math.cos(ang)*spd,"vy":math.sin(ang)*spd,
                                  "col":(255,150,50)})

    def _fire_ring(self,count,spd):
        for i in range(count):
            ang=math.radians(i*360//count)
            self.bullets.append({"rect":pygame.Rect(self.rect.centerx-4,self.rect.centery,8,14),
                                  "vx":math.cos(ang)*spd,"vy":math.sin(ang)*spd,"col":PURPLE})

    def update(self,player_rect):
        self.pulse=(self.pulse+0.08)%(math.pi*2)
        if self.hp<self.max_hp*0.5 and self.phase==1:
            self.phase=2; self.speed*=1.6; self.rage_flash=80
        if self.rage_flash>0: self.rage_flash-=1
        if self.entering:
            self.rect.y+=3
            if self.rect.y>=50: self.entering=False
            return
        # movement - improved boundary bounce
        self.rect.x+=int(self.speed*self.direction)
        # force back if out of bounds
        if self.rect.right>=WIDTH-10:
            self.rect.right=WIDTH-10; self.direction=-1
        elif self.rect.left<=10:
            self.rect.left=10; self.direction=1
        if random.random()<0.003 and not self.tractor_active:
            self.tractor_active=True; self.tractor_timer=0
        if self.tractor_active:
            self.tractor_timer+=1
            pull=0.003+self.phase*0.002
            dx=self.rect.centerx-player_rect.centerx; dy=self.rect.centery-player_rect.centery
            player_rect.x+=int(dx*pull); player_rect.y+=int(dy*pull)
            if self.tractor_timer>90: self.tractor_active=False
        self.attack_timer+=1
        self._attack(player_rect)
        for b in self.bullets[:]:
            b["rect"].x+=b["vx"]; b["rect"].y+=b["vy"]
            if b["rect"].y>HEIGHT+20 or b["rect"].x<-20 or b["rect"].x>WIDTH+20:
                self.bullets.remove(b)

    def _attack(self,pr): pass

    def take_damage(self): self.hp-=1; return self.hp<=0

    def _draw_body(self,surface):
        if self.image:
            col_img=self.image.copy()
            if self.phase==2 and (pygame.time.get_ticks()//100)%2==0:
                col_img.fill((80,0,0,0),special_flags=pygame.BLEND_RGBA_ADD)
            # boss glow effect
            gs=int(self.size//2+10+math.sin(self.pulse)*5)
            gsurf=pygame.Surface((gs*2,gs*2),pygame.SRCALPHA)
            r,g,b=self.color
            ga=50 if self.phase==1 else 90
            pygame.draw.ellipse(gsurf,(r,g,b,ga),(0,0,gs*2,gs*2))
            surface.blit(gsurf,(self.rect.centerx-gs,self.rect.centery-gs))
            surface.blit(col_img,self.rect)
            # boss name + story tag
            if hasattr(self,'story_tag'):
                tg=tiny_font.render(self.story_tag,True,self.color)
                surface.blit(tg,(self.rect.centerx-tg.get_width()//2,self.rect.bottom+4))
        else:
            # fallback draw when no image
            r,g,b=self.color
            # body
            pygame.draw.rect(surface,self.color,self.rect,border_radius=14)
            # core
            pygame.draw.ellipse(surface,(min(255,r+80),min(255,g+80),min(255,b+80)),
                               self.rect.inflate(-self.size//3,-self.size//3))
            # eyes
            ey=self.rect.top+self.size//3
            for ex_off in [-self.size//4, self.size//4]:
                pygame.draw.circle(surface,(255,50,50),(self.rect.centerx+ex_off,ey),6)
                pygame.draw.circle(surface,(255,200,200),(self.rect.centerx+ex_off,ey),3)
            pygame.draw.rect(surface,WHITE,self.rect,3,border_radius=14)
            lbl=small_font.render(self.name,True,WHITE)
            surface.blit(lbl,lbl.get_rect(center=(self.rect.centerx,self.rect.bottom-12)))

    def draw(self,surface):
        if self.entering and self.rect.y<-self.size: return
        if self.tractor_active:
            for i in range(3):
                off=i*4-4
                pygame.draw.line(surface,(0,200,255),(self.rect.centerx+off,self.rect.bottom),(self.rect.centerx+off,HEIGHT),2)
        bx=20; bw=WIDTH-40
        pygame.draw.rect(surface,GRAY,(bx,14,bw,14))
        ratio=max(0,self.hp/self.max_hp)
        hpcol=RED if self.phase==2 else (0,200,100)
        pygame.draw.rect(surface,hpcol,(bx,14,int(bw*ratio),14))
        pygame.draw.rect(surface,WHITE,(bx,14,bw,14),1)
        nlbl=tiny_font.render(f"{self.name}  {self.hp}/{self.max_hp}",True,WHITE)
        surface.blit(nlbl,(bx+4,16))
        if self.rage_flash>0:
            ss=pygame.Surface((self.rect.w+20,self.rect.h+20),pygame.SRCALPHA)
            ss.fill((255,50,50,int(100*self.rage_flash/80))); surface.blit(ss,(self.rect.x-10,self.rect.y-10))
        self._draw_body(surface)
        for b in self.bullets:
            pygame.draw.circle(surface,b["col"],(int(b["rect"].centerx),int(b["rect"].centery)),5)

class BossScout(BossBase):
    def __init__(self,stage):
        super().__init__(stage,"SCOUT",20+stage*2,90,2.2,CYAN)
        self.story_tag="[ Vanguard Commander Kaiser ]"
    def _attack(self,pr):
        iv=30 if self.phase==1 else 18
        if self.attack_timer>=iv:
            self.attack_timer=0
            if self.phase==1:
                self._fire_spread(pr.centerx,pr.centery,3,3.5)
            else:
                self._fire_spread(pr.centerx,pr.centery,3,3.5)
                self._fire_spiral(2.8)  # spiral added in phase 2

class BossCarrier(BossBase):
    def __init__(self,stage):
        super().__init__(stage,"CARRIER",40+stage*2,110,1.4,ORANGE)
        self.story_tag="[ Fleet Admiral Argon ]"
        self.spawn_timer=0; self.spawned=[]
    def _attack(self,pr):
        iv=45 if self.phase==1 else 28
        if self.attack_timer>=iv:
            self.attack_timer=0; self._fire_spread(pr.centerx,pr.centery,4,3.0)
        self.spawn_timer+=1
        sp_iv=180 if self.phase==1 else 100
        if self.spawn_timer>=sp_iv and len(self.spawned)<4:
            self.spawn_timer=0
            for side in [-1,1]:
                e=Enemy(self.rect.centerx+side*20,self.rect.bottom,"fast")
                e.state="dive"; e.base_x=float(e.rect.x); e.base_y=float(e.rect.y); e.target_y=float(e.rect.y)
                self.spawned.append(e)
    def update(self,pr):
        super().update(pr)
        for e in self.spawned[:]:
            e.update(pr)
            if e.rect.top>HEIGHT+50: self.spawned.remove(e)
    def draw(self,surface):
        super().draw(surface)
        for e in self.spawned: e.draw(surface)

class BossTitan(BossBase):
    def __init__(self,stage):
        super().__init__(stage,"TITAN",70+stage*3,130,0.8,GRAY)
        self.story_tag="[ Iron Warrior Titan ]"
    def _attack(self,pr):
        iv=55 if self.phase==1 else 30
        if self.attack_timer>=iv:
            self.attack_timer=0; self._fire_spread(pr.centerx,pr.centery,5,2.8,math.pi/4)
        self.spread_timer+=1
        if self.spread_timer>=180:
            self.spread_timer=0
            self._fire_ring(12,2.5)
            if self.phase==2: self._fire_cross(3.5)  # cross burst in phase 2

class BossPhantom(BossBase):
    def __init__(self,stage):
        super().__init__(stage,"PHANTOM",50+stage*2,100,2.0,PURPLE)
        self.story_tag="[ Shadow Assassin Phantom ]"
        self.cloak_timer=0; self.cloaked=False
    def update(self,pr):
        super().update(pr)
        self.cloak_timer+=1
        if not self.cloaked and self.cloak_timer>120:
            self.cloaked=True; self.cloak_timer=0
        elif self.cloaked and self.cloak_timer>60:
            self.cloaked=False; self.cloak_timer=0
    def _attack(self,pr):
        iv=35 if self.phase==1 else 20
        if self.attack_timer>=iv:
            self.attack_timer=0; self._fire_spread(pr.centerx,pr.centery,4,3.2)
    def draw(self,surface):
        if self.cloaked:
            pygame.draw.rect(surface,(150,80,255,60),self.rect,border_radius=10)
            pygame.draw.rect(surface,PURPLE,self.rect,2,border_radius=10)
            for b in self.bullets:
                pygame.draw.circle(surface,b["col"],(int(b["rect"].centerx),int(b["rect"].centery)),5)
        else:
            super().draw(surface)

class BossOmega(BossBase):
    def __init__(self,stage):
        super().__init__(stage,"OMEGA",60+stage*3,105,0,RED)
        self.story_tag="[ Orbital Overlord Omega ]"
        self.orbit_angle=0.0; self.orbit_r=150; self.orbit_spd=0.018
    def update(self,pr):
        self.pulse=(self.pulse+0.08)%(math.pi*2)
        if self.hp<self.max_hp*0.5 and self.phase==1:
            self.phase=2; self.orbit_spd*=1.6; self.rage_flash=80
        if self.rage_flash>0: self.rage_flash-=1
        if self.entering:
            self.rect.y+=3
            if self.rect.y>=200: self.entering=False
            return
        self.orbit_angle+=self.orbit_spd
        cx=int(WIDTH//2+math.cos(self.orbit_angle)*self.orbit_r)
        cy=int(180+math.sin(self.orbit_angle)*80)
        # clamp to screen bounds
        cx=max(self.size//2+10,min(WIDTH-self.size//2-10,cx))
        cy=max(50,min(HEIGHT//2,cy))
        self.rect.centerx=cx; self.rect.centery=cy
        if random.random()<0.003 and not self.tractor_active:
            self.tractor_active=True; self.tractor_timer=0
        if self.tractor_active:
            self.tractor_timer+=1
            pull=0.004; dx=self.rect.centerx-pr.centerx; dy=self.rect.centery-pr.centery
            pr.x+=int(dx*pull); pr.y+=int(dy*pull)
            if self.tractor_timer>90: self.tractor_active=False
        self.attack_timer+=1; self._attack(pr)
        for b in self.bullets[:]:
            b["rect"].x+=b["vx"]; b["rect"].y+=b["vy"]
            if b["rect"].y>HEIGHT+20 or b["rect"].x<-20 or b["rect"].x>WIDTH+20:
                self.bullets.remove(b)
    def _attack(self,pr):
        iv=32 if self.phase==1 else 18
        if self.attack_timer>=iv:
            self.attack_timer=0; self._fire_spread(pr.centerx,pr.centery,4,3.5)
        self.spread_timer+=1
        if self.spread_timer>=160:
            self.spread_timer=0; self._fire_ring(10,3.0)
        # continuous spiral in phase 2
        if self.phase==2 and self.attack_timer%4==0:
            self._fire_spiral(2.5)

class BossHydra(BossBase):
    def __init__(self,stage):
        super().__init__(stage,"HYDRA",80+stage*3,120,1.2,TEAL)
        self.story_tag="[ Triple-Headed Hydra ]"
        self.heads=[{"x":0,"alive":True,"hp":20+stage},
                    {"x":0,"alive":True,"hp":20+stage},
                    {"x":0,"alive":True,"hp":20+stage}]
        self.head_size=28
    def _alive_count(self): return sum(1 for h in self.heads if h["alive"])
    def _attack(self,pr):
        iv=40 if self.phase==1 else 22
        if self.attack_timer>=iv:
            self.attack_timer=0
            for h in self.heads:
                if h["alive"]: self._fire(pr.centerx,pr.centery,3.0+self.phase*0.4)
    def update(self,pr):
        super().update(pr)
        offsets=[-40,0,40]
        for i,h in enumerate(self.heads):
            h["x"]=self.rect.centerx+offsets[i]
    def take_damage(self):
        alive=[h for h in self.heads if h["alive"]]
        if alive:
            target=random.choice(alive); target["hp"]-=1
            if target["hp"]<=0: target["alive"]=False
            if self._alive_count()==0: self.hp-=1
        else:
            self.hp-=1
        return self.hp<=0
    def draw(self,surface):
        super().draw(surface)
        for h in self.heads:
            col=TEAL if h["alive"] else GRAY
            pygame.draw.circle(surface,col,(int(h["x"]),self.rect.bottom-10),self.head_size//2)
            pygame.draw.circle(surface,WHITE,(int(h["x"]),self.rect.bottom-10),self.head_size//2,2)
            if h["alive"]:
                pygame.draw.circle(surface,RED,(int(h["x"])-5,self.rect.bottom-14),4)
                pygame.draw.circle(surface,RED,(int(h["x"])+5,self.rect.bottom-14),4)

class BossMothership(BossBase):
    def __init__(self,stage):
        super().__init__(stage,"MOTHERSHIP",100+stage*4,140,1.0,NAVY)
        self.story_tag="[ Carrier Commander Nightmare ]"
        self.phase3=False; self.beam_timer=0; self.beam_active=False; self.beam_x=WIDTH//2
    def update(self,pr):
        super().update(pr)
        if self.hp<self.max_hp*0.25 and not self.phase3:
            self.phase3=True; self.speed*=1.4; self.show_rage=80
        self.beam_timer+=1
        if self.beam_timer>220:
            self.beam_timer=0; self.beam_active=True; self.beam_x=pr.centerx
        if self.beam_active:
            if pr.colliderect(pygame.Rect(self.beam_x-8,self.rect.bottom,16,HEIGHT)):
                pass
            self.beam_timer+=1
            if self.beam_timer>30: self.beam_active=False; self.beam_timer=0
    def _attack(self,pr):
        iv=25 if self.phase==1 else 14
        if self.attack_timer>=iv:
            self.attack_timer=0
            if self.phase==1: self._fire_spread(pr.centerx,pr.centery,5,3.0)
            else:
                self._fire_spread(pr.centerx,pr.centery,7,3.5,math.pi/3)
                if self.phase3: self._fire_ring(16,2.8)
    def draw(self,surface):
        super().draw(surface)
        if self.beam_active:
            bs=pygame.Surface((16,HEIGHT),pygame.SRCALPHA)
            bs.fill((255,255,100,140)); surface.blit(bs,(self.beam_x-8,self.rect.bottom))

class BossBerserker(BossBase):
    def __init__(self,stage):
        super().__init__(stage,"BERSERKER",85+stage*3,115,2.8,RED)
        self.story_tag="[ Berserker Warlord ]"
        self.spin=0.0; self.spin_spd=0.04; self.burst_t=0
    def update(self,pr):
        super().update(pr)
        if not self.entering:
            self.spin+=self.spin_spd*(1.5 if self.phase==2 else 1.0)
    def _attack(self,pr):
        iv=20 if self.phase==1 else 10
        if self.attack_timer>=iv:
            self.attack_timer=0
            # note
            for i in range(4 if self.phase==1 else 6):
                ang=self.spin+math.radians(i*90 if self.phase==1 else i*60)
                spd=3.5+self.phase*0.8
                self.bullets.append({
                    "rect":pygame.Rect(self.rect.centerx-4,self.rect.centery,8,14),
                    "vx":math.cos(ang)*spd,"vy":math.sin(ang)*spd,
                    "col":(255,80,80) if self.phase==1 else RED
                })
        self.burst_t+=1
        if self.burst_t>=90:
            self.burst_t=0; self._fire_ring(12 if self.phase==2 else 8, 2.8)

# note
class BossHydra2(BossHydra):
    def __init__(self,stage):
        super().__init__(stage)
        self.name="HYDRA II"; self.max_hp=100+stage*3; self.hp=self.max_hp
        self.heads=[{"x":0,"alive":True,"hp":25+stage} for _ in range(5)]
        self.regen_t=0
    def update(self,pr):
        super().update(pr)
        self.regen_t+=1
        if self.regen_t>=300 and self.phase==2:
            self.regen_t=0
            dead=[h for h in self.heads if not h["alive"]]
            if dead:
                dead[0]["alive"]=True; dead[0]["hp"]=10
    def _attack(self,pr):
        iv=28 if self.phase==1 else 15
        if self.attack_timer>=iv:
            self.attack_timer=0
            for h in self.heads:
                if h["alive"]: self._fire(pr.centerx,pr.centery,3.2+self.phase*0.5)
    def draw(self,surface):
        BossBase.draw(self,surface)
        offsets=[-60,-30,0,30,60]
        for i,h in enumerate(self.heads):
            col=(0,220,180) if h["alive"] else GRAY
            hx=self.rect.centerx+offsets[i]
            pygame.draw.circle(surface,col,(int(hx),self.rect.bottom-8),14)
            pygame.draw.circle(surface,WHITE,(int(hx),self.rect.bottom-8),14,2)
            if h["alive"]:
                pygame.draw.circle(surface,RED,(int(hx)-5,self.rect.bottom-12),3)
                pygame.draw.circle(surface,RED,(int(hx)+5,self.rect.bottom-12),3)

# note
class BossOmega2(BossOmega):
    def __init__(self,stage):
        super().__init__(stage)
        self.name="OMEGA II"; self.max_hp=120+stage*4; self.hp=self.max_hp
        self.orbit_r=160; self.orbit_spd=0.025
        self.clone_t=0; self.clones=[]
    def _attack(self,pr):
        iv=18 if self.phase==1 else 10
        if self.attack_timer>=iv:
            self.attack_timer=0
            self._fire_spread(pr.centerx,pr.centery,6 if self.phase==1 else 9,3.8,math.pi/3)
        self.spread_timer+=1
        if self.spread_timer>=100:
            self.spread_timer=0; self._fire_ring(14,3.2)
        self.clone_t+=1
        if self.clone_t>=200 and len(self.clones)<2:
            self.clone_t=0
            cx=random.randint(60,WIDTH-60)
            self.clones.append({"x":float(cx),"y":80.0,"hp":15,"t":0})
        for cl in self.clones[:]:
            cl["t"]+=1; cl["x"]+=math.sin(cl["t"]*0.05)*1.5
            if random.random()<0.02:
                ang=math.atan2(pr.centery-cl["y"],pr.centerx-cl["x"])
                self.bullets.append({
                    "rect":pygame.Rect(int(cl["x"])-4,int(cl["y"]),8,14),
                    "vx":math.cos(ang)*3.0,"vy":math.sin(ang)*3.0,"col":PURPLE})
    def draw(self,surface):
        super().draw(surface)
        for cl in self.clones:
            pygame.draw.circle(surface,PURPLE,(int(cl["x"]),int(cl["y"])),16)
            pygame.draw.circle(surface,WHITE,(int(cl["x"]),int(cl["y"])),16,2)
            bar_w=30
            pygame.draw.rect(surface,GRAY,(int(cl["x"])-15,int(cl["y"])-22,bar_w,4))
            pygame.draw.rect(surface,PURPLE,(int(cl["x"])-15,int(cl["y"])-22,
                int(bar_w*cl["hp"]/15),4))

def make_boss(stage):
    plan=STAGE_PLAN.get(stage,{})
    btype=plan.get("boss","scout")
    mapping={
        "scout":BossScout,"carrier":BossCarrier,"titan":BossTitan,
        "phantom":BossPhantom,"omega":BossOmega,"hydra":BossHydra,
        "mothership":BossMothership,"berserker":BossBerserker,
        "hydra2":BossHydra2,"omega2":BossOmega2
    }
    cls=mapping.get(btype,BossScout)
    return cls(stage)

# ============================================================
# STAGE EVENTS  (6 types)
# ============================================================
class StageEvent:
    AMBUSH=1; ASTEROID=2; BONUS=3; METEOR=4; RESCUE=5; FORMATION=6

    def __init__(self,etype,stage):
        self.type=etype; self.stage=stage; self.timer=0
        self.duration=420; self.objects=[]; self.done=False
        self.score=0; self.msg_t=90

        if etype==self.AMBUSH:
            for i in range(6+stage//3):
                side=-1 if i%2==0 else 1
                x=-40 if side==-1 else WIDTH+40
                self.objects.append({"rect":pygame.Rect(x,random.randint(80,HEIGHT//2),28,28),"vx":side*3,"vy":0.4,"hp":1})
        elif etype==self.ASTEROID:
            for _ in range(10+stage//2):
                r=random.randint(12,28)
                self.objects.append({"rect":pygame.Rect(random.randint(20,WIDTH-20),-r*2,r*2,r*2),
                                    "vy":random.uniform(2,4+stage*0.1),"r":r,"rot":0,
                                    "rotspd":random.uniform(-3,3),"hp":1})
        elif etype==self.BONUS:
            for row in range(3):
                for col in range(6):
                    self.objects.append({"rect":pygame.Rect(55+col*62,-80-row*50,26,26),"target_y":80+row*50,"hp":1,"val":500})
        elif etype==self.METEOR:
            for _ in range(8+stage//4):
                r=random.randint(18,38)
                self.objects.append({"rect":pygame.Rect(random.randint(0,WIDTH-r*2),-r*2,r*2,r*2),
                                     "vy":random.uniform(3,5+stage*0.15),"r":r,"rot":0,"rotspd":random.uniform(-2,2),"hp":2})
        elif etype==self.RESCUE:
            self.objects.append({"rect":pygame.Rect(WIDTH//2-20,-50,40,40),"vy":0.8,"hp":5,"rescued":False})
        elif etype==self.FORMATION:
            for i in range(12+stage//3):
                angle=math.radians(i*30)
                x=WIDTH//2+math.cos(angle)*180
                self.objects.append({"rect":pygame.Rect(x,-60-i*20,26,26),"angle":angle,"speed":2.5,"hp":1})

    def update(self,player_rect,bullets,particles,float_texts):
        self.timer+=1
        if self.msg_t>0: self.msg_t-=1

        if self.type==self.AMBUSH:
            for o in list(self.objects):
                if o not in self.objects: continue
                o["rect"].x+=o["vx"]; o["rect"].y+=o["vy"]
                if o["rect"].left>WIDTH+60 or o["rect"].right<-60:
                    if o in self.objects: self.objects.remove(o)
                    continue
                for b in list(bullets):
                    if b not in bullets: continue
                    if b.colliderect(o["rect"]):
                        try: bullets.remove(b)
                        except ValueError: pass
                        particles+=[Particle(o["rect"].centerx,o["rect"].centery,ORANGE) for _ in range(8)]
                        float_texts.append(FloatText(o["rect"].centerx,o["rect"].centery,"+200",CYAN))
                        self.score+=200
                        if o in self.objects: self.objects.remove(o)
                        break

        elif self.type in (self.ASTEROID,self.METEOR):
            col=GRAY if self.type==self.ASTEROID else ORANGE
            for o in list(self.objects):
                if o not in self.objects: continue
                o["rect"].y+=o["vy"]; o["rot"]+=o["rotspd"]
                if o["rect"].top>HEIGHT+50:
                    if o in self.objects: self.objects.remove(o)
                    continue
                for b in list(bullets):
                    if b not in bullets: continue
                    if b.colliderect(o["rect"]):
                        try: bullets.remove(b)
                        except ValueError: pass
                        o["hp"]-=1
                        if o["hp"]<=0:
                            v=200 if self.type==self.METEOR else 150
                            float_texts.append(FloatText(o["rect"].centerx,o["rect"].centery,f"+{v}",WHITE))
                            self.score+=v
                            if o in self.objects: self.objects.remove(o)
                            break
                        else:
                            particles+=[Particle(o["rect"].centerx,o["rect"].centery,col,3) for _ in range(6)]

        elif self.type==self.BONUS:
            for o in list(self.objects):
                if o not in self.objects: continue
                if o["rect"].y<o["target_y"]: o["rect"].y+=2
                for b in list(bullets):
                    if b not in bullets: continue
                    if b.colliderect(o["rect"]):
                        try: bullets.remove(b)
                        except ValueError: pass
                        particles+=[Particle(o["rect"].centerx,o["rect"].centery,GOLD,4) for _ in range(10)]
                        float_texts.append(FloatText(o["rect"].centerx,o["rect"].centery,"+500!",GOLD,28))
                        self.score+=500
                        if o in self.objects: self.objects.remove(o)
                        break

        elif self.type==self.RESCUE:
            for o in list(self.objects):
                o["rect"].y+=o["vy"]
                if o["rect"].colliderect(player_rect) and not o["rescued"]:
                    o["rescued"]=True; self.score+=3000
                    float_texts.append(FloatText(o["rect"].centerx,o["rect"].centery,"RESCUED! +3000",GREEN,30))
                    self.objects.remove(o); break
                if o["rect"].top>HEIGHT+50: self.objects.remove(o)

        elif self.type==self.FORMATION:
            for o in list(self.objects):
                if o not in self.objects: continue
                o["angle"]+=0.03; o["rect"].y+=o["speed"]
                o["rect"].x=int(WIDTH//2+math.cos(o["angle"])*180)
                if o["rect"].top>HEIGHT+50:
                    if o in self.objects: self.objects.remove(o)
                    continue
                for b in list(bullets):
                    if b not in bullets: continue
                    if b.colliderect(o["rect"]):
                        try: bullets.remove(b)
                        except ValueError: pass
                        particles+=[Particle(o["rect"].centerx,o["rect"].centery,LIME) for _ in range(6)]
                        float_texts.append(FloatText(o["rect"].centerx,o["rect"].centery,"+180",LIME))
                        self.score+=180
                        if o in self.objects: self.objects.remove(o)
                        break

        if self.timer>=self.duration: self.done=True
        if not self.objects: self.done=True

    def draw(self,surface):
        LABELS={self.AMBUSH:"!! AMBUSH !!",self.ASTEROID:"ASTEROID FIELD!",self.BONUS:"BONUS STAGE!",
                self.METEOR:"METEOR SHOWER!",self.RESCUE:"RESCUE MISSION!",self.FORMATION:"ENEMY FORMATION!"}
        LCOLS={self.AMBUSH:RED,self.ASTEROID:GRAY,self.BONUS:GOLD,self.METEOR:ORANGE,self.RESCUE:GREEN,self.FORMATION:LIME}
        if self.msg_t>0:
            txt=big_font.render(LABELS.get(self.type,"EVENT!"),True,LCOLS.get(self.type,WHITE))
            surface.blit(txt,(WIDTH//2-txt.get_width()//2,HEIGHT//2-80))

        if self.type==self.AMBUSH:
            for o in self.objects:
                pygame.draw.rect(surface,ORANGE,o["rect"],border_radius=4)
                pygame.draw.rect(surface,WHITE,o["rect"],1,border_radius=4)
        elif self.type in (self.ASTEROID,self.METEOR):
            col=(160,160,160) if self.type==self.ASTEROID else (220,100,40)
            for o in self.objects:
                cx,cy=o["rect"].center; r=o["r"]
                pts=[]
                for i in range(8):
                    ang=math.radians(i*45+o["rot"])
                    dr=r*0.75 if i%2 else r
                    pts.append((cx+math.cos(ang)*dr, cy+math.sin(ang)*dr))
                if len(pts)>=3:
                    pygame.draw.polygon(surface,col,pts)
                    pygame.draw.polygon(surface,WHITE,pts,2)
                if self.type==self.METEOR:
                    pygame.draw.circle(surface,ORANGE,(cx,cy),4)
        elif self.type==self.BONUS:
            for o in self.objects:
                pygame.draw.rect(surface,GOLD,o["rect"],border_radius=5)
                pygame.draw.rect(surface,WHITE,o["rect"],2,border_radius=5)
                lbl=small_font.render("$",True,BLACK); surface.blit(lbl,lbl.get_rect(center=o["rect"].center))
        elif self.type==self.RESCUE:
            for o in self.objects:
                pygame.draw.rect(surface,GREEN,o["rect"],border_radius=8)
                pygame.draw.rect(surface,WHITE,o["rect"],2,border_radius=8)
                lbl=small_font.render("POD",True,BLACK); surface.blit(lbl,lbl.get_rect(center=o["rect"].center))
        elif self.type==self.FORMATION:
            for o in self.objects:
                pygame.draw.rect(surface,LIME,o["rect"],border_radius=4)
                pygame.draw.rect(surface,WHITE,o["rect"],1,border_radius=4)

# ============================================================
# TOUCH CONTROLS
# ============================================================
class TouchControls:
    """
    Left half: Anywhere-drag virtual joystick (finger down = new center)
    Right half: FIRE + SP buttons
    Top bar: Pause / Music / Shop
    """
    JOY_R  = 58    # outer ring radius
    JOY_KR = 24    # knob radius
    JOY_DEAD = 8   # deadzone px
    BTN  = 56
    GAP  = 10
    MAR  = 14
    BOT  = 16

    def __init__(self):
        b=self.BTN; g=self.GAP; m=self.MAR

        # Joystick center set dynamically on touch-down
        self.joy_cx   = self.JOY_R + m + 4
        self.joy_cy   = HEIGHT - self.JOY_R - self.BOT - 8
        self.joy_anchor_x = self.joy_cx   # current anchor (moves on touch-down)
        self.joy_anchor_y = self.joy_cy
        self.joy_dx   = 0.0
        self.joy_dy   = 0.0
        self.joy_fid  = None
        self.joy_active = False

        # Right-side buttons
        fw = b*2 + g
        fx = WIDTH - fw - m
        fbot = HEIGHT - b - self.BOT
        self.btn_shoot   = pygame.Rect(fx,     fbot, fw, b)
        self.btn_special = pygame.Rect(fx-b-g, fbot, b,  b)

        # Top-right tiny buttons
        self.btn_pause = pygame.Rect(WIDTH-36, 6, 28, 28)
        self.btn_shop  = pygame.Rect(WIDTH-70, 6, 28, 28)
        self.btn_music = pygame.Rect(WIDTH-104,6, 28, 28)

        # State
        self.shoot_held   = False
        self.special_held = False
        self.shop_held    = False
        self.pause_tapped = False
        self.music_tapped = False
        self.finger_map   = {}   # fid -> zone name
        self._sp_ready    = False
        self._music_on    = True

        # Pre-render button surfaces
        self._surf_shoot_n = self._make_btn("FIRE",(180,30,40),(255,120,130))
        self._surf_shoot_p = self._make_btn("FIRE",(220,60,70),(255,200,200))
        self._surf_sp_n    = self._make_bolt((160,130,0),(255,220,50))
        self._surf_sp_p    = self._make_bolt((200,170,0),(255,255,100))

    def _make_btn(self,label,bg,fg):
        b=self.BTN; g=self.GAP; w=b*2+g; h=b
        s=pygame.Surface((w,h),pygame.SRCALPHA)
        pygame.draw.rect(s,(*bg,200),(0,0,w,h),border_radius=h//2)
        pygame.draw.rect(s,(*fg,160),(0,0,w,h),2,border_radius=h//2)
        t=small_font.render(label,True,fg)
        s.blit(t,t.get_rect(center=(w//2,h//2)))
        return s

    def _make_bolt(self,bg,fg):
        b=self.BTN; h=b
        s=pygame.Surface((b,h),pygame.SRCALPHA)
        pygame.draw.rect(s,(*bg,200),(0,0,b,h),border_radius=h//2)
        pygame.draw.rect(s,(*fg,160),(0,0,b,h),2,border_radius=h//2)
        cx,cy=b//2,h//2
        bolt=[(cx+3,cy-12),(cx-5,cy-1),(cx+4,cy-1),(cx-3,cy+12),(cx+5,cy+1),(cx-4,cy+1)]
        pygame.draw.polygon(s,fg,bolt)
        return s

    def _is_left_zone(self, pos):
        """Left 55% of screen = joystick zone"""
        return pos[0] < WIDTH * 0.55

    def _is_button(self, pos):
        """Check if pos hits any action/top button"""
        return (self.btn_shoot.collidepoint(pos) or
                self.btn_special.collidepoint(pos) or
                self.btn_pause.collidepoint(pos) or
                self.btn_shop.collidepoint(pos) or
                self.btn_music.collidepoint(pos))

    def _update_joy(self, pos):
        dx = pos[0] - self.joy_anchor_x
        dy = pos[1] - self.joy_anchor_y
        dist = math.hypot(dx, dy)
        if dist < self.JOY_DEAD:
            self.joy_dx = 0.0; self.joy_dy = 0.0
        else:
            clamped = min(dist, self.JOY_R)
            self.joy_dx = (dx / dist) * (clamped / self.JOY_R)
            self.joy_dy = (dy / dist) * (clamped / self.JOY_R)

    def handle_touch(self, pos, pressed, fid=0):
        if pressed:
            if self._is_button(pos):
                # Button handling
                if self.btn_shoot.collidepoint(pos):
                    self.finger_map[fid]="shoot"; self.shoot_held=True
                elif self.btn_special.collidepoint(pos):
                    self.finger_map[fid]="special"; self.special_held=True
                elif self.btn_pause.collidepoint(pos):
                    self.finger_map[fid]="pause"; self.pause_tapped=True
                elif self.btn_shop.collidepoint(pos):
                    self.finger_map[fid]="shop"; self.shop_held=True
                elif self.btn_music.collidepoint(pos):
                    self.finger_map[fid]="music"; self.music_tapped=True
            elif self._is_left_zone(pos) and self.joy_fid is None:
                # Anywhere-drag: anchor joystick at touch point
                self.joy_fid = fid
                self.joy_anchor_x = pos[0]
                self.joy_anchor_y = pos[1]
                self.joy_active = True
                self.joy_dx = 0.0; self.joy_dy = 0.0
                self.finger_map[fid] = "joy"
            elif self.joy_fid is None:
                # Right zone but not a button - still allow joystick
                self.joy_fid = fid
                self.joy_anchor_x = pos[0]
                self.joy_anchor_y = pos[1]
                self.joy_active = True
                self.joy_dx = 0.0; self.joy_dy = 0.0
                self.finger_map[fid] = "joy"
        else:
            zone = self.finger_map.pop(fid, None)
            if zone == "joy":
                self.joy_fid = None; self.joy_active = False
                self.joy_dx = 0.0;   self.joy_dy = 0.0
                # reset anchor to default position
                self.joy_anchor_x = self.joy_cx
                self.joy_anchor_y = self.joy_cy
            elif zone == "shoot":   self.shoot_held = False
            elif zone == "special": self.special_held = False
            elif zone == "shop":    self.shop_held = False
            elif zone == "pause":   pass   # tapped flags cleared by main loop
            elif zone == "music":   pass

    def handle_motion(self, pos, fid=0):
        zone = self.finger_map.get(fid)
        if zone == "joy":
            self._update_joy(pos)
        elif zone == "shoot":
            # if finger slides off shoot button, keep held
            pass

    def is_pressed(self, name):
        if name == "shoot":   return self.shoot_held
        if name == "special": return self.special_held
        if name == "shop":    return self.shop_held
        T = 0.30
        if name == "left":  return self.joy_dx < -T
        if name == "right": return self.joy_dx >  T
        if name == "up":    return self.joy_dy < -T
        if name == "down":  return self.joy_dy >  T
        return False

    def get_joy_axis(self):
        return self.joy_dx, self.joy_dy

    def draw(self, surface):
        cx = self.joy_anchor_x if self.joy_active else self.joy_cx
        cy = self.joy_anchor_y if self.joy_active else self.joy_cy
        jr = self.JOY_R; kr = self.JOY_KR

        # Outer ring (always visible, faint when idle)
        ring_a = 100 if self.joy_active else 40
        ring_col = (80,160,255,ring_a)
        rs = pygame.Surface((jr*2+4, jr*2+4), pygame.SRCALPHA)
        pygame.draw.circle(rs, (60,120,255, ring_a//3), (jr+2,jr+2), jr)
        pygame.draw.circle(rs, (80,150,255, ring_a),    (jr+2,jr+2), jr, 2)
        surface.blit(rs, (cx-jr-2, cy-jr-2))

        # Direction arrows (faint guide)
        for ddx,ddy in [(-1,0),(1,0),(0,-1),(0,1)]:
            pygame.draw.line(surface,(80,140,255,50),
                (cx,cy),(cx+ddx*(jr-8),cy+ddy*(jr-8)),1)

        # Knob
        kx = cx + int(self.joy_dx * jr)
        ky = cy + int(self.joy_dy * jr)
        ks = pygame.Surface((kr*2+6, kr*2+6), pygame.SRCALPHA)
        pygame.draw.circle(ks, (0,0,0,50),   (kr+3,kr+4), kr)   # shadow
        if self.joy_active:
            pygame.draw.circle(ks, (130,190,255,240), (kr+3,kr+3), kr)
            pygame.draw.circle(ks, (200,230,255,180), (kr+3,kr+3), kr, 2)
            pygame.draw.circle(ks, (255,255,255,160), (kr+3-kr//3,kr+3-kr//3), kr//3)
        else:
            pygame.draw.circle(ks, (70,130,220,130), (kr+3,kr+3), kr)
            pygame.draw.circle(ks, (120,170,255,100), (kr+3,kr+3), kr, 2)
        surface.blit(ks, (kx-kr-3, ky-kr-3))

        # FIRE button
        s = self._surf_shoot_p if self.shoot_held else self._surf_shoot_n
        surface.blit(s, self.btn_shoot)

        # SP button
        s2 = self._surf_sp_p if self.special_held else self._surf_sp_n
        surface.blit(s2, self.btn_special)

        # SP ready glow
        if self._sp_ready:
            pulse = int(abs(math.sin(pygame.time.get_ticks()*0.006))*80)+60
            rg = pygame.Surface((self.BTN+16, self.BTN+16), pygame.SRCALPHA)
            pygame.draw.rect(rg,(255,215,0,pulse),(0,0,self.BTN+16,self.BTN+16),
                             3,border_radius=self.BTN//2+3)
            surface.blit(rg,(self.btn_special.x-8, self.btn_special.y-8))
            ul=tiny_font.render("USE!",True,(255,215,0))
            surface.blit(ul,(self.btn_special.centerx-ul.get_width()//2,self.btn_special.y-16))

        # Top buttons
        for rect,label,held in [
            (self.btn_pause,"||",False),
            (self.btn_shop, "$", self.shop_held),
            (self.btn_music,"N" if self._music_on else "M",False),
        ]:
            ts=pygame.Surface((rect.w,rect.h),pygame.SRCALPHA)
            ts.fill((200,200,200,80) if held else (100,100,100,60))
            surface.blit(ts,rect)
            pygame.draw.rect(surface,(180,180,180),rect,1,border_radius=5)
            tl=tiny_font.render(label,True,WHITE)
            surface.blit(tl,tl.get_rect(center=rect.center))

class GameManager:
    def __init__(self):
        self.player=Player(); self.enemies=[]; self.boss=None
        self.bullets=[]; self.lasers=[]; self.enemy_bullets=[]
        self.particles=[]; self.powerups=[]; 
        self.coins=[]   
        self.float_texts=[]
        self.missiles=[]; self.plasmas=[]; self.shockwaves=[]; self.flashes=[]
        self.ally_bullets=[]  # Phoenix ally colored bullets
        self.stage=1; self.formation_dir=1; self.all_descended=False
        self.clear_timer=0; self.dive_cd=0; self.event=None
        self.star_offset=0.0; self.screen_shake=0
        self.bg_tint=(0,0,0)
        # new systems
        self.combo_meter=ComboMeter()
        self.formation_bonus=FormationBonus()
        self.levelup_screen=None
        self.stage_intro_timer=0; self.stage_intro_text=""
        # new systems
        self.total_kills_run=0; self.boss_kills_run=0
        self.boss_nodmg=True   # reset on player hit during boss
        self.slow_factor=1.0   # for killcam slowmo
        PowerUp.load_icons(); Enemy.load_frames()
        self._spawn_enemies()


    def _weighted_etype(self,mix):
        etypes=[e for e,_ in mix]; weights=[w for _,w in mix]
        total=sum(weights); rnd=random.uniform(0,total)
        for et,w in zip(etypes,weights):
            rnd-=w
            if rnd<=0: return et
        return etypes[-1]

    def _spawn_enemies(self):
        self.enemies=[]; self.all_descended=False; self.dive_cd=120
        plan=STAGE_PLAN.get(self.stage,{})
        mix=plan.get("mix",[("normal",1)])
        tier=plan.get("tier",0)
        self.bg_tint=plan.get("tint",(0,0,0))
        self.enemy_tier=tier
        rows=min(2+self.stage//3,5); cols=min(5+self.stage//8,8)
        for row in range(rows):
            for col in range(cols):
                x=50+col*(WIDTH-100)//max(1,cols-1); y=60+row*42
                if row==0 and tier>=2:
                    etype="elite" if tier<5 else "armored"
                else:
                    etype=self._weighted_etype(mix)
                e=Enemy(x,-50-row*50,etype,tier)
                e.target_y=float(y); e.base_y=float(y); e.base_x=float(x)
                self.enemies.append(e)
        # formation bonus init
        self.formation_bonus.start(len(self.enemies))
        # stage intro
        theme=PLANET_THEMES[tier%len(PLANET_THEMES)]
        self.stage_intro_timer=150
        self.stage_intro_text=f"STAGE {self.stage}  -  {theme['name']}"

    def _powerup(self,x,y):
        if random.random()<min(0.30,0.15+self.stage*0.01): self.powerups.append(PowerUp(x,y))

    MAX_PARTICLES=120

    def _chain_explode(self,x,y,col,pl,depth=0):
        """Chain explosion - nearby enemies take splash damage"""
        if depth>=3: return   # max 3 chain depth
        chain_r=55
        for e in self.enemies[:]:
            if e not in self.enemies: continue
            dist=math.hypot(e.rect.centerx-x,e.rect.centery-y)
            if 0<dist<chain_r:
                self._explode(e.rect.centerx,e.rect.centery,e.color,5)
                if e.take_hit():
                    pts=self._get_enemy_score(e); pl.score+=int(pts*1.5)  # chain bonus
                    pl.combo=min(30,pl.combo+1); pl.multiplier=min(8,1+pl.combo//3)
                    leveled=pl.add_kill()
                    if leveled: self.levelup_screen=LevelUpScreen(stats.pilot_level)
                    self.combo_meter.hit(pl.combo,pl.multiplier)
                    self.total_kills_run+=1; stats.total_kills+=1
                    ex,ey=e.rect.centerx,e.rect.centery
                    self.float_texts.append(FloatText(ex,ey,f"CHAIN! +{int(pts*1.5)}",(255,200,50),20,'bounce'))
                    if e in self.enemies: self.enemies.remove(e)
                    self._chain_explode(ex,ey,col,pl,depth+1)

    def _explode(self,x,y,col,n=8,big=False):
        # cap n and respect global limit
        avail=self.MAX_PARTICLES-len(self.particles)
        if avail<=0: return
        if big:
            n=min(n,16); n=min(n,avail)
            spd=3.5
            self.particles+=[Particle(x,y,col,spd,0.05,'circle') for _ in range(n)]
            self.particles+=[Particle(x,y,(255,255,200),spd*1.1,0.03,'spark') for _ in range(min(4,avail-n))]
            self.particles+=[Particle(x,y,col,2.5,0,'star') for _ in range(min(4,avail-n-4))]
            if len(self.shockwaves)<3:
                self.shockwaves.append(ShockWave(x,y,col))
            if len(self.flashes)<2:
                self.flashes.append(FlashEffect(col,5))
            self.screen_shake=10
        else:
            n=min(n,8); n=min(n,avail)
            spd=2.5
            self.particles+=[Particle(x,y,col,spd,0,'circle') for _ in range(n)]
            if n>=4:
                self.particles+=[Particle(x,y,(255,255,200),spd*1.1,0,'spark') for _ in range(min(2,avail-n))]

    def _lightning_chain(self):
        """     :                 """
        if not self.enemies:
            return
        
        #        :               
        pl=self.player
        closest=None
        closest_dist=9999
        for e in self.enemies:
            dist=math.hypot(e.rect.centerx-pl.rect.centerx, e.rect.centery-pl.rect.centery)
            if dist<closest_dist:
                closest_dist=dist
                closest=e
        
        if not closest:
            return
        
        #       (   8  )
        chain=[closest]
        remaining=[e for e in self.enemies if e!=closest]
        
        for _ in range(7):
            if not remaining:
                break
            last=chain[-1]
            nearest=None
            nearest_dist=9999
            for e in remaining:
                dist=math.hypot(e.rect.centerx-last.rect.centerx, e.rect.centery-last.rect.centery)
                if dist<200 and dist<nearest_dist:  # 200px       
                    nearest_dist=dist
                    nearest=e
            if nearest:
                chain.append(nearest)
                remaining.remove(nearest)
            else:
                break
        
        #        +    
        for i, e in enumerate(chain):
            if e.take_hit():
                if e in self.enemies:
                    self.enemies.remove(e)
            pts=150*(i+1)  #             
            pl.score+=pts
            pl.add_kill()
            for _ in range(15):
                self.particles.append(Particle(e.rect.centerx, e.rect.centery, YELLOW))
            self.float_texts.append(FloatText(e.rect.centerx, e.rect.centery, f"+{pts}", CYAN))
        
        #        (         )
        for i in range(len(chain)-1):
            e1=chain[i]
            e2=chain[i+1]
            for _ in range(5):
                mx=(e1.rect.centerx+e2.rect.centerx)//2
                my=(e1.rect.centery+e2.rect.centery)//2
                self.particles.append(Particle(mx, my, (100,200,255)))

    def _get_enemy_score(self,e):
        return e.score_val*self.player.multiplier

    def update(self,keys,touch=None):
        pl=self.player; pl.update()
        self.star_offset=(self.star_offset+0.4)%HEIGHT
        if self.screen_shake>0: self.screen_shake-=1
        dx=keys.get("dx", (-1 if keys.get("left") else 0)+(1 if keys.get("right") else 0))
        dy=keys.get("dy", (-1 if keys.get("up") else 0)+(1 if keys.get("down") else 0))
        pl.move(dx,dy)
        if keys.get("charge"): pl.charge_special()
        if keys.get("special") and pl.use_special(): self._lightning_chain()
        if keys.get("shoot"):
            nb,nl,nm,np2=self.player.shoot()
            self.bullets.extend(nb)
            if nl: self.lasers.append(nl)
            if nm: self.missiles.append(nm)
            if np2: self.plasmas.append(np2)

        # Phoenix ally fires independently
        if pl.ally_active:
            ab,am=pl.ally_fire(self.enemies)
            if ab: self.ally_bullets.extend(ab)
            if am: self.missiles.append(am)
        for b in self.bullets[:]:
            b.y-=8
            if b.y<-20: self.bullets.remove(b)
        for L in self.lasers[:]:
            if not L.update(): self.lasers.remove(L)
        for ft in self.float_texts[:]:
            if not ft.update(): self.float_texts.remove(ft)
        if len(self.float_texts)>10:
            self.float_texts=self.float_texts[-10:]
        if self.clear_timer>0:
            self.clear_timer-=1
            if self.clear_timer==0: self._next_stage()
            return
        if self.event:
            self.event.update(pl.rect,self.bullets,self.particles,self.float_texts)
            if self.event.type in (StageEvent.ASTEROID, StageEvent.METEOR):
                for o in self.event.objects[:]:
                    if o["rect"].colliderect(pl.rect) and pl.invincible==0:
                        pl.hit()
                        self._explode(pl.rect.centerx,pl.rect.centery,ORANGE,8)
                        break
            if self.event.done:
                pl.score+=self.event.score
                self.float_texts.append(FloatText(WIDTH//2,HEIGHT//2-40,f"EVENT +{self.event.score}!",GOLD,36))
                self.event=None; self.clear_timer=60
            return
        if self.boss:
            self.boss.update(pl.rect)
            if hasattr(self.boss,"spawned"):
                for e in self.boss.spawned[:]:
                    for b in self.bullets[:]:
                        if b.colliderect(e.rect):
                            self.bullets.remove(b); self.boss.spawned.remove(e)
                            self._explode(e.rect.centerx,e.rect.centery,CYAN,6); break
            if hasattr(self.boss,"beam_active") and self.boss.beam_active:
                br=pygame.Rect(self.boss.beam_x-8,self.boss.rect.bottom,16,HEIGHT)
                if br.colliderect(pl.rect) and pl.invincible==0: pl.hit()
            for b in self.bullets[:]:
                if self.boss and b.colliderect(self.boss.rect) and not self.boss.entering:
                    self.bullets.remove(b)
                    if self.boss.take_damage():
                        bx,by=self.boss.rect.centerx,self.boss.rect.centery
                        self._explode(bx,by,ORANGE,40,True)
                        pl.score+=8000+self.stage*300; sounds.play("explosion")
                        self.boss_kills_run+=1
                        kill_effect.boss_kill(bx,by)
                        if self.boss_nodmg:
                            achievements.check(boss_nodmg=1)
                        self.boss=None; self.clear_timer=100
                        sounds.switch_bgm(boss_mode=False)
                    else: self._explode(b.centerx,b.centery,YELLOW,4)
            for L in self.lasers:
                if self.boss and not self.boss.entering:
                    lr=pygame.Rect(L.x-L.width,0,L.width*2,HEIGHT)
                    if lr.colliderect(self.boss.rect):
                        for _ in range(2):
                            if self.boss and self.boss.take_damage():
                                self._explode(self.boss.rect.centerx,self.boss.rect.centery,ORANGE,40,True)
                                pl.score+=8000+self.stage*300; sounds.play("explosion")
                                self.boss=None; self.clear_timer=100
                                sounds.switch_bgm(boss_mode=False)
                                break
            if self.boss:
                for b in self.boss.bullets[:]:
                    if b["rect"].colliderect(pl.rect) and pl.invincible==0:
                        pl.hit(); self.boss.bullets.remove(b)
                if pl.invincible==0 and self.boss and self.boss.rect.colliderect(pl.rect): pl.hit()
            return
        form=[e for e in self.enemies if e.state=="formation"]
        if form:
            spd=0.5+self.stage*0.04
            for e in form: e.rect.x+=spd*self.formation_dir
            if any(e.rect.right>WIDTH-8 or e.rect.left<8 for e in form):
                self.formation_dir*=-1
                drop=min(5+self.stage//5,12)
                for e in form:
                    new_y=e.base_y+drop
                    if new_y < HEIGHT*0.58:   # hard ceiling - never below 58% height
                        e.rect.y=int(new_y); e.base_y=new_y
        # remove any enemy that somehow escaped screen (safety net)
        self.enemies=[e for e in self.enemies
                      if e.rect.top<HEIGHT+60 and e.rect.bottom>-80
                      and e.rect.left>-100 and e.rect.right<WIDTH+100]
        if self.dive_cd>0: self.dive_cd-=1
        slow=pl.timeslow_active
        for e in self.enemies: e.update(pl.rect,slow)
        diving=sum(1 for e in self.enemies if e.state=="dive"); max_div=1+self.stage//4
        if self.dive_cd==0 and diving<max_div:
            cands=[e for e in self.enemies if e.state=="formation" and e.rect.y<HEIGHT//2]
            if cands and random.random()<0.005+self.stage*0.001:
                random.choice(cands).start_dive(); self.dive_cd=max(20,55-self.stage*2)
        if not self.all_descended and all(e.state!="descending" for e in self.enemies):
            self.all_descended=True
        if self.all_descended and random.random()<0.005+self.stage*0.001:
            cands=[e for e in self.enemies if e.state=="formation" and e.rect.y<HEIGHT*0.6]
            if cands:
                sh=random.choice(cands); self.enemy_bullets.append(pygame.Rect(sh.rect.centerx-2,sh.rect.bottom,4,10))
        bspd=4+self.stage//5
        for b in self.enemy_bullets[:]:
            b.y+=bspd
            if b.y>HEIGHT+10: self.enemy_bullets.remove(b)
            elif b.colliderect(pl.rect) and pl.invincible==0: pl.hit(); self.enemy_bullets.remove(b)
        for L in self.lasers:
            lr=pygame.Rect(L.x-L.width,0,L.width*2,HEIGHT)
            for e in self.enemies[:]:
                if lr.colliderect(e.rect):
                    if e.take_hit():
                        pts=self._get_enemy_score(e); pl.score+=pts; pl.combo=min(30,pl.combo+1)
                        pl.multiplier=min(8,1+pl.combo//3)
                        leveled=pl.add_kill()
                        if leveled: self.levelup_screen=LevelUpScreen(stats.pilot_level)
                        self.combo_meter.hit(pl.combo,pl.multiplier)
                        kill_effect.streak_lightning(pl.combo,self.combo_meter._get_tier(pl.combo)[3])
                        self.total_kills_run+=1; stats.total_kills+=1
                        self._explode(e.rect.centerx,e.rect.centery,e.color)
                        self.float_texts.append(FloatText(e.rect.centerx,e.rect.centery,f"+{pts}",CYAN))
                        self._spawn_splits(e); self._powerup(e.rect.centerx,e.rect.centery)
                        if random.random()<0.15+stats.upgrade_bonus("luck"):
                            self.coins.append(Coin(e.rect.centerx, e.rect.centery))
                        self.enemies.remove(e)
                    else: self._explode(e.rect.centerx,e.rect.centery,WHITE,3)
        for b in self.bullets[:]:
            for e in self.enemies[:]:
                if b.colliderect(e.rect):
                    if b in self.bullets: self.bullets.remove(b)
                    if e.take_hit():
                        pts=self._get_enemy_score(e); pl.score+=pts; pl.combo=min(30,pl.combo+1)
                        pl.multiplier=min(8,1+pl.combo//3)
                        leveled=pl.add_kill()
                        if leveled: self.levelup_screen=LevelUpScreen(stats.pilot_level)
                        self.combo_meter.hit(pl.combo,pl.multiplier)
                        kill_effect.streak_lightning(pl.combo,self.combo_meter._get_tier(pl.combo)[3])
                        self.total_kills_run+=1; stats.total_kills+=1
                        self._explode(e.rect.centerx,e.rect.centery,e.color)
                        self.float_texts.append(FloatText(e.rect.centerx,e.rect.centery,f"+{pts}",CYAN))
                        self._spawn_splits(e); self._powerup(e.rect.centerx,e.rect.centery)
                        if random.random()<0.15+stats.upgrade_bonus("luck"):
                            self.coins.append(Coin(e.rect.centerx, e.rect.centery))
                        ex,ey=e.rect.centerx,e.rect.centery; ecol=e.color
                        self.enemies.remove(e)
                        if random.random()<0.12+pl.combo*0.015:
                            self._chain_explode(ex,ey,ecol,pl)
                        if e.behaviour=="bomb":
                            for ang_off in [-0.4,0,0.4]:
                                ang=math.pi/2+ang_off
                                self.enemy_bullets.append({"rect":pygame.Rect(e.rect.centerx-2,e.rect.centery,4,10),
                                                           "vx":math.cos(ang)*3,"vy":math.sin(ang)*3})
                    else: self._explode(e.rect.centerx,e.rect.centery,WHITE,3)
                    break
        for b in self.enemy_bullets[:]:
            if isinstance(b,dict):
                b["rect"].x+=b["vx"]; b["rect"].y+=b["vy"]
                if b["rect"].y>HEIGHT+10: self.enemy_bullets.remove(b)
                elif b["rect"].colliderect(pl.rect) and pl.invincible==0: pl.hit(); self.enemy_bullets.remove(b)
        if pl.invincible==0:
            for e in self.enemies:
                if e.rect.colliderect(pl.rect): pl.hit(); self._explode(pl.rect.centerx,pl.rect.centery,WHITE,20); break
        # combo decay reset
        if pl.combo>0 and pl.streak_timer==0: pl.combo=0; pl.multiplier=1; self.combo_meter.reset()
        self.combo_meter.update()
        # formation bonus
        fb=self.formation_bonus.update(len(self.enemies),self.all_descended)
        if fb>0:
            pl.score+=fb
            self.float_texts.append(FloatText(WIDTH//2,HEIGHT//2-30,f"FORMATION BONUS! +{fb}",GOLD,32,'streak'))
        # stage intro countdown
        if self.stage_intro_timer>0: self.stage_intro_timer-=1
        # kill_effect
        kill_effect.update()
        # achievement check
        achievements.check(
            kills=self.total_kills_run,
            combo=pl.combo,
            stage=self.stage,
            pilot=stats.pilot_level,
            score=pl.score,
            boss_nodmg=1 if self.boss_nodmg else 0,
            streak=pl.kill_streak,
            ally=1 if pl.ally_active else 0,
        )
        achievements.update()
        # daily mission update
        daily.update(kills=self.total_kills_run,combo=pl.combo,
                     stage=self.stage,score=pl.score,boss=self.boss_kills_run)
        # stage clear -> update max_stage
        if not self.enemies and not self.boss and self.all_descended and self.clear_timer==0:
            if self.stage > stats.max_stage_cleared:
                stats.max_stage_cleared = self.stage
                stats.save()
                # stage 100 achievement
                if self.stage>=100:
                    achievements.check(stage=100)
                    stats.unlock_title("champion")
        # auto-unlock titles from achievements
        for t in TITLES:
            if t["id"] not in stats.unlocked_titles:
                ach_id=t.get("from","")
                if ach_id in achievements.unlocked:
                    if stats.unlock_title(t["id"]):
                        self.float_texts.append(FloatText(WIDTH//2,HEIGHT//2-60,
                            f"TITLE UNLOCKED: {t['name']}",t["col"],24,'streak'))
        # coin magnet
        if upgrade_tree.get("magnet")>0:
            mag_r=60+upgrade_tree.get("magnet")*30
            for c in self.coins:
                dx=pl.rect.centerx-c.rect.centerx; dy=pl.rect.centery-c.rect.centery
                dist=math.hypot(dx,dy)
                if dist<mag_r and dist>1:
                    c.rect.x+=int(dx/dist*4); c.rect.y+=int(dy/dist*4)
        for p in self.powerups[:]:
            if not p.update(): self.powerups.remove(p)
            elif p.rect.colliderect(pl.rect):
                res=pl.add_powerup(p.type); self.powerups.remove(p)
                self._explode(p.rect.centerx,p.rect.centery,p.color,8)
                if res=="bomb": self._screen_clear()
        self.particles=[p for p in self.particles if p.update()]
        if len(self.particles)>self.MAX_PARTICLES:
            self.particles=self.particles[-self.MAX_PARTICLES:]
        if self.all_descended and not self.enemies and not self.boss and not self.event:
            plan=STAGE_PLAN.get(self.stage,{})
            if plan.get("boss"):
                self.boss=make_boss(self.stage)
                sounds.switch_bgm(boss_mode=True)
            elif plan.get("event"):
                etype_map={"ambush":StageEvent.AMBUSH,"asteroid":StageEvent.ASTEROID,
                           "bonus":StageEvent.BONUS,"meteor":StageEvent.METEOR,
                           "rescue":StageEvent.RESCUE,"formation":StageEvent.FORMATION}
                ev=etype_map.get(plan["event"],StageEvent.BONUS)
                self.event=StageEvent(ev,self.stage)
            else:
                self.clear_timer=80
        if self.stage>100 and not self.enemies and not self.boss:
            self.player.show_message("YOU WIN! ALL 100 STAGES CLEARED!")
        for c in self.coins[:]:
            if not c.update():
                self.coins.remove(c)
            elif c.rect.colliderect(pl.rect):
                stats.coins += c.value
                self.float_texts.append(FloatText(c.rect.centerx, c.rect.centery, f"+{c.value}", GOLD))
                self.coins.remove(c)

        # missile update
        for m in self.missiles[:]:
            alive,mrect=m.update(self.enemies)
            if not alive: self.missiles.remove(m); continue
            hit=False
            for e in self.enemies[:]:
                if mrect.colliderect(e.rect):
                    self._explode(e.rect.centerx,e.rect.centery,ORANGE,12,False)
                    if e.take_hit():
                        pts=self._get_enemy_score(e); pl.score+=pts; pl.add_kill()
                        self.float_texts.append(FloatText(e.rect.centerx,e.rect.centery,f"+{pts}",ORANGE,24,'bounce'))
                        self._spawn_splits(e); self._powerup(e.rect.centerx,e.rect.centery)
                        self.enemies.remove(e)
                    if m in self.missiles: self.missiles.remove(m)
                    hit=True; break
            if not hit and self.boss and not self.boss.entering:
                if mrect.colliderect(self.boss.rect):
                    self._explode(self.boss.rect.centerx,self.boss.rect.centery,ORANGE,16,True)
                    if self.boss.take_damage():
                        pl.score+=8000+self.stage*300; sounds.play("explosion")
                        self.boss=None; self.clear_timer=100; sounds.switch_bgm(boss_mode=False)
                    if m in self.missiles: self.missiles.remove(m)

        # plasma update
        for p2 in self.plasmas[:]:
            alive,prect=p2.update()
            if not alive: self.plasmas.remove(p2); continue
            hit_enemies=[e for e in self.enemies if prect.colliderect(e.rect)]
            for e in hit_enemies:
                if e.take_hit():
                    pts=self._get_enemy_score(e); pl.score+=pts; pl.add_kill()
                    self.float_texts.append(FloatText(e.rect.centerx,e.rect.centery,f"+{pts}",LIME,24,'bounce'))
                    if e in self.enemies: self.enemies.remove(e)
                self._explode(e.rect.centerx,e.rect.centery,(0,255,160),6)
            if hit_enemies and p2 in self.plasmas: self.plasmas.remove(p2)

        # shockwave/flash
        for sw in self.shockwaves[:]:
            if not sw.update(): self.shockwaves.remove(sw)
        for fl in self.flashes[:]:
            if not fl.update(): self.flashes.remove(fl)

        # ally bullets update & collision
        for ab in self.ally_bullets[:]:
            ab["rect"].x+=int(ab["vx"]); ab["rect"].y+=int(ab["vy"])
            if ab["rect"].y<-20:
                self.ally_bullets.remove(ab); continue
            hit=False
            for e in self.enemies[:]:
                if ab["rect"].colliderect(e.rect):
                    self._explode(e.rect.centerx,e.rect.centery,(255,220,80),6)
                    if e.take_hit():
                        pts=self._get_enemy_score(e); pl.score+=pts; pl.add_kill()
                        self.float_texts.append(FloatText(e.rect.centerx,e.rect.centery,f"+{pts}",(255,220,80),20,'bounce'))
                        self._spawn_splits(e); self._powerup(e.rect.centerx,e.rect.centery)
                        self.enemies.remove(e)
                    if ab in self.ally_bullets: self.ally_bullets.remove(ab)
                    hit=True; break
            if not hit and self.boss and not self.boss.entering:
                if ab["rect"].colliderect(self.boss.rect):
                    self._explode(self.boss.rect.centerx,self.boss.rect.centery,(255,220,80),8)
                    if self.boss.take_damage():
                        pl.score+=8000+self.stage*300; sounds.play("explosion")
                        self.boss=None; self.clear_timer=100; sounds.switch_bgm(boss_mode=False)
                    if ab in self.ally_bullets: self.ally_bullets.remove(ab)


    def _spawn_splits(self,e):
        if e.behaviour=="split":
            for side in [-1,1]:
                mini=Enemy(e.rect.centerx+side*14,e.rect.centery,"fast")
                mini.state="dive"; mini.base_x=float(mini.rect.x)
                mini.base_y=float(mini.rect.y); mini.target_y=float(mini.rect.y)
                mini.rect.w=16; mini.rect.h=16
                self.enemies.append(mini)

    def _screen_clear(self):    
        for e in self.enemies:
            for _ in range(8):
                self.particles.append(Particle(e.rect.centerx, e.rect.centery, YELLOW))
            self.player.score += 150
        self.enemies.clear()
        self.enemy_bullets.clear()

    def _next_stage(self):
        self.stage+=1; self.player.score+=self.stage*150
        self.bullets.clear(); self.enemy_bullets.clear()
        self.powerups.clear(); self.particles.clear()
        self.lasers.clear(); self.float_texts.clear()
        self.missiles.clear(); self.plasmas.clear()
        self.shockwaves.clear(); self.flashes.clear(); self.ally_bullets.clear()
        self.formation_dir=1; self.boss=None; self.event=None
        self._spawn_enemies()

    def draw(self,surface):
        cm=self.combo_meter
        cx=cm.shake_x if cm.combo>=5 else 0
        cy=cm.shake_y if cm.combo>=5 else 0
        ox=(random.randint(-3,3) if self.screen_shake>0 else 0)+cx
        oy=(random.randint(-3,3) if self.screen_shake>0 else 0)+cy
        surf=surface if (ox==0 and oy==0) else pygame.Surface((WIDTH,HEIGHT))
        tier=getattr(self,'enemy_tier',0); theme=BG_THEMES[min(tier,9)]
        r,g,b=theme['sky']; surf.fill((r,g,b))
        surf.blit(get_nebula(tier),(0,0))
        if theme['planet'] and tier>0:
            pr2,pg2,pb2=theme['planet']; planet_r=40+tier*3
            ps=pygame.Surface((planet_r*2,planet_r*2),pygame.SRCALPHA)
            pygame.draw.circle(ps,(pr2,pg2,pb2,55),(planet_r,planet_r),planet_r)
            pygame.draw.circle(ps,(pr2,pg2,pb2,110),(planet_r,planet_r),planet_r,4)
            surf.blit(ps,(WIDTH-70-planet_r,60-planet_r))
        off=int(self.star_offset); t2=pygame.time.get_ticks()
        for sx,sy,sr in STARS_SLOW: pygame.draw.circle(surf,(160,160,180),(sx,(sy+off//2)%HEIGHT),sr)
        for sx,sy,sr in STARS_FAST: pygame.draw.circle(surf,(80,80,100),(sx,(sy+off)%HEIGHT),sr)
        for sx,sy,sr,ph in STARS_TWINKLE:
            a=int(abs(math.sin(t2*0.002+ph))*200)+55
            ts=pygame.Surface((sr*2,sr*2),pygame.SRCALPHA)
            pygame.draw.circle(ts,(255,255,255,a),(sr,sr),sr)
            surf.blit(ts,(sx-sr,(sy+off)%HEIGHT-sr))
        if tier>0:
            tw=tiny_font.render(theme['name'],True,WHITE); tw.set_alpha(35); surf.blit(tw,(4,HEIGHT-12))
        stg=font.render(f"STAGE  {self.stage} / 100",True,WHITE)
        surf.blit(stg,(WIDTH//2-stg.get_width()//2,3))
        if self.clear_timer>0 and not self.event:
            pct=self.clear_timer/80
            cs=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); cs.fill((0,255,200,int(40*pct))); surf.blit(cs,(0,0))
            msg=big_font.render("STAGE CLEAR!",True,CYAN); surf.blit(msg,(WIDTH//2-msg.get_width()//2,HEIGHT//2-20))
        if self.event: self.event.draw(surf)
        self.player.draw(surf)
        for L in self.lasers: L.draw(surf)
        for b in self.bullets: pygame.draw.rect(surf,CYAN,b,border_radius=2)
        # missiles
        for m in self.missiles: m.draw(surf)
        # plasma
        for p2 in self.plasmas: p2.draw(surf)
        # ally bullets - gold
        for ab in self.ally_bullets:
            r=ab["rect"]
            pygame.draw.rect(surf,(255,220,80),r,border_radius=2)
            pygame.draw.rect(surf,(255,255,180),r.inflate(-2,-4),border_radius=1)
        for b in self.enemy_bullets:
            if isinstance(b,dict): pygame.draw.circle(surf,ORANGE,(int(b["rect"].centerx),int(b["rect"].centery)),5)
            else: pygame.draw.rect(surf,RED,b,border_radius=2)
        for e in self.enemies: e.draw(surf)
        if self.boss: self.boss.draw(surf)
        for p in self.powerups: p.draw(surf)
        for sw in self.shockwaves: sw.draw(surf)
        for p in self.particles: p.draw(surf)
        for c in self.coins:c.draw(surf)
        for ft in self.float_texts: ft.draw(surf)
        for fl in self.flashes: fl.draw(surf)
        # kill_effect border (drawn over everything)
        kill_effect.draw_border(surf)
        # achievement notification
        achievements.draw(surf)
        # daily mission HUD
        daily.draw_hud(surf)
        sc=font.render(f"Score: {self.player.score:,}",True,WHITE); surf.blit(sc,(8,24))
        # combo meter (replaces old inline combo)
        self.combo_meter.draw(surf)
        # formation bonus hint
        self.formation_bonus.draw(surf,len(self.enemies))
        # stage intro animation
        if self.stage_intro_timer>0:
            ratio=self.stage_intro_timer/150
            alpha=int(min(255,ratio*400))
            tier=STAGE_PLAN.get(self.stage,{}).get("tier",0)
            theme=PLANET_THEMES[tier%len(PLANET_THEMES)]
            # slide in from top
            ty=int((1-min(1,ratio*3))*(-60))+HEIGHT//2-80
            panel=pygame.Surface((WIDTH-40,52),pygame.SRCALPHA)
            panel.fill((*theme["accent"],int(40*ratio)))
            pygame.draw.rect(panel,(*theme["accent"],int(180*ratio)),(0,0,WIDTH-40,52),2,border_radius=10)
            surf.blit(panel,(20,ty-6))
            it=big_font.render(self.stage_intro_text,True,theme["accent"])
            it.set_alpha(alpha)
            surf.blit(it,(WIDTH//2-it.get_width()//2,ty))
        # pilot XP bar bottom
        xp_w=WIDTH-16; xp_h=5; xp_y=HEIGHT-7
        pygame.draw.rect(surf,(30,30,60),(8,xp_y,xp_w,xp_h),border_radius=2)
        xp_ratio=stats.pilot_xp/max(1,stats.xp_to_next())
        xp_col=(80,200,255) if stats.pilot_level<10 else (255,200,50)
        pygame.draw.rect(surf,xp_col,(8,xp_y,int(xp_w*xp_ratio),xp_h),border_radius=2)
        lv=tiny_font.render(f"PILOT Lv.{stats.pilot_level}",True,xp_col)
        surf.blit(lv,(8,xp_y-12))
        # XP flash
        if self.player.xp_flash>0:
            xf=tiny_font.render(f"+{self.player.xp_flash_amt}XP",True,(80,220,255))
            xf.set_alpha(int(200*self.player.xp_flash/40))
            surf.blit(xf,(8+int(xp_w*xp_ratio)-10,xp_y-22))
            self.player.xp_flash-=1
        if self.player.message_timer>0:
            alpha=min(255,self.player.message_timer*4)
            style=getattr(self.player,'message_style','normal')
            msg_col=YELLOW
            if style=='streak': msg_col=(255,100,50)
            msg=big_font.render(self.player.message,True,msg_col)
            # glow
            if style in ('bounce','streak'):
                glow=big_font.render(self.player.message,True,WHITE)
                glow.set_alpha(int(60*alpha/255))
                surf.blit(glow,(WIDTH//2-glow.get_width()//2+2,HEIGHT//2-68))
            msg.set_alpha(alpha)
            surf.blit(msg,(WIDTH//2-msg.get_width()//2,HEIGHT//2-70))
        gw=76; pygame.draw.rect(surf,GRAY,(WIDTH-gw-8,46,gw,8))
        gcol=GOLD if self.player.special_ready else BLUE
        pygame.draw.rect(surf,gcol,(WIDTH-gw-8,46,int(gw*self.player.special_gauge/100),8))
        surf.blit(tiny_font.render("SP",True,WHITE),(WIDTH-gw-20,46))
        py_ind=62
        if self.player.double_fighter: surf.blit(tiny_font.render(f"DBL {self.player.double_timer//60+1}s",True,CYAN),(WIDTH-60,py_ind)); py_ind+=14
        if self.player.laser_active:  surf.blit(tiny_font.render(f"LASER {self.player.laser_timer//60+1}s",True,(180,80,255)),(WIDTH-70,py_ind)); py_ind+=14
        if self.player.shield_active: surf.blit(tiny_font.render(f"SHLD {self.player.shield_timer//60+1}s",True,(0,255,200)),(WIDTH-70,py_ind))
        if self.player.lives<=0:
            ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); ov.fill((0,0,0,170)); surf.blit(ov,(0,0))
            surf.blit(big_font.render("GAME OVER",True,RED),(WIDTH//2-big_font.size("GAME OVER")[0]//2,HEIGHT//2-55))
            surf.blit(font.render(f"Final Score: {self.player.score:,}",True,WHITE),(WIDTH//2-90,HEIGHT//2))
            surf.blit(font.render("Tap or press R to restart",True,GRAY),(WIDTH//2-100,HEIGHT//2+36))
        if ox or oy: surface.fill(BLACK); surface.blit(surf,(ox,oy))
        surface.blit(small_font.render(f"Coins: {stats.coins}", True, GOLD), (ox, oy))
class Shop:
    def __init__(self):
        self.selected = 0
        self.message = ""
        self.message_timer = 0
    
    def update(self):
        if self.message_timer > 0:
            self.message_timer -= 1
    
    def buy(self, player):
        if self.selected >= len(SHOP_ITEMS):
            return
        item = SHOP_ITEMS[self.selected]
        if stats.coins >= item.get("price",item.get("cost",0)):
            stats.coins -= item.get("price",item.get("cost",0))
            result=player.add_powerup(item["type"])
            if result=="bomb": return "bomb"
            self.message = f"Purchased: {item['name']}!"
        else:
            self.message = "Not enough coins!"
            self.message_timer = 60
        return None
    
    def draw(self, surface):
        ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 200))
        surface.blit(ov, (0, 0))
        surface.blit(big_font.render("SHOP", True, GOLD), (WIDTH//2-40, 60))
        surface.blit(small_font.render(f"Coins: {stats.coins}", True, GOLD), (8, 44))
        for i, item in enumerate(SHOP_ITEMS):
            y = 120 + i * 48
            if y > HEIGHT - 40: break
            color = WHITE if stats.coins >= item.get("price",item.get("cost",0)) else GRAY
            if i == self.selected:
                pygame.draw.rect(surface, (50,50,80), (20, y-4, WIDTH-40, 42), border_radius=8)
            surface.blit(font.render(f"{item['icon']} {item['name']}", True, color), (40, y))
            surface.blit(tiny_font.render(f"{item.get('price',0)}c  {item.get('desc','')}", True, GOLD if stats.coins >= item.get("price",0) else GRAY), (40, y+22))
        if self.message_timer > 0:
            msg = font.render(self.message, True, YELLOW)
            surface.blit(msg, (WIDTH//2 - msg.get_width()//2, HEIGHT-50))

shop = Shop()

# ============================================================
# MAIN LOOP
# ============================================================

# Title screen
def draw_title(surface, tick, demo_game):
    demo_game.draw(surface)
    ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); ov.fill((0,0,0,160)); surface.blit(ov,(0,0))

    # animated lance beam behind title
    beam_x=WIDTH//2; beam_alpha=int(60+math.sin(tick*0.05)*40)
    for bw,ba in [(80,20),(50,40),(20,beam_alpha)]:
        bs=pygame.Surface((bw,HEIGHT),pygame.SRCALPHA)
        bs.fill((100,160,255,ba))
        surface.blit(bs,(beam_x-bw//2,0))

    # NOVA  (big, pulsing blue-white)
    pls=abs(math.sin(tick*0.04))*40+180
    tf_big=pygame.font.Font(None,88)
    tf_sub=pygame.font.Font(None,52)

    # glow layer
    glow=tf_big.render("NOVA",True,(int(pls*0.4),int(pls*0.6),255))
    for ox,oy in [(-3,0),(3,0),(0,-3),(0,3)]:
        glow.set_alpha(60)
        surface.blit(glow,(WIDTH//2-glow.get_width()//2+ox,HEIGHT//2-145+oy))

    nova=tf_big.render("NOVA",True,(int(pls),int(pls),255))
    surface.blit(nova,(WIDTH//2-nova.get_width()//2,HEIGHT//2-145))

    # LANCE  (accent gold/orange)
    lance_col=(255,int(160+math.sin(tick*0.06)*50),40)
    lance=tf_big.render("LANCE",True,lance_col)
    for ox,oy in [(-2,0),(2,0),(0,-2),(0,2)]:
        gs=tf_big.render("LANCE",True,(100,60,0))
        gs.set_alpha(80); surface.blit(gs,(WIDTH//2-lance.get_width()//2+ox,HEIGHT//2-75+oy))
    surface.blit(lance,(WIDTH//2-lance.get_width()//2,HEIGHT//2-75))

    # divider line
    line_w=int(140+math.sin(tick*0.03)*20)
    pygame.draw.line(surface,(100,160,255),(WIDTH//2-line_w,HEIGHT//2-8),(WIDTH//2+line_w,HEIGHT//2-8),2)
    pygame.draw.line(surface,lance_col,(WIDTH//2-line_w//2,HEIGHT//2-4),(WIDTH//2+line_w//2,HEIGHT//2-4),1)

    # tagline
    sub=font.render("STAR FRONTIER ASSAULT",True,(180,200,255))
    surface.blit(sub,(WIDTH//2-sub.get_width()//2,HEIGHT//2+8))

    # blink start
    if (tick//28)%2==0:
        s=big_font.render("TAP TO START",True,(255,255,80))
        surface.blit(s,(WIDTH//2-s.get_width()//2,HEIGHT//2+50))

    # best score
    hi=font.render(f"BEST: {stats.high_score:,}",True,GOLD)
    surface.blit(hi,(WIDTH//2-hi.get_width()//2,HEIGHT//2+82))

    # pilot level
    plv=tiny_font.render(f"PILOT Lv.{stats.pilot_level}  |  Coins: {stats.coins}",True,(140,160,200))
    surface.blit(plv,(WIDTH//2-plv.get_width()//2,HEIGHT//2+106))

    cr=tiny_font.render("M=Music  Tab=Shop  U=Upgrades  H=Hangar  T=Titles  G=Stages",True,(80,80,110))
    surface.blit(cr,(WIDTH//2-cr.get_width()//2,HEIGHT-18))

def draw_pause(surface):
    ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); ov.fill((0,0,20,190)); surface.blit(ov,(0,0))
    panel=pygame.Surface((300,180),pygame.SRCALPHA); panel.fill((20,20,60,220))
    pygame.draw.rect(panel,(80,80,180,200),(0,0,300,180),2,border_radius=14)
    surface.blit(panel,(WIDTH//2-150,HEIGHT//2-90))
    pt=big_font.render("PAUSED",True,CYAN)
    surface.blit(pt,(WIDTH//2-pt.get_width()//2,HEIGHT//2-80))
    for i,(lb,hb) in enumerate([("Continue","tap || or P key"),
                                  ("Music on/off","tap N btn or M key"),
                                  ("Shop","tap $ or Tab key")]):
        y=HEIGHT//2-20+i*38
        surface.blit(font.render(lb,True,WHITE),(WIDTH//2-130,y))
        surface.blit(small_font.render(hb,True,GRAY),(WIDTH//2+20,y+4))

def draw_shop_full(surface, shop_obj, player):
    ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); ov.fill((0,0,20,215)); surface.blit(ov,(0,0))
    hdr=big_font.render("SHOP",True,GOLD)
    surface.blit(hdr,(WIDTH//2-hdr.get_width()//2,8))
    cl=font.render(f"Coins: {stats.coins}",True,GOLD)
    surface.blit(cl,(WIDTH//2-cl.get_width()//2,46))
    pygame.draw.line(surface,GRAY,(20,70),(WIDTH-20,70),1)

    item_h=56; visible=8; start_y=78
    sel=shop_obj.selected
    # scroll window so selected item stays visible
    scroll=max(0, sel-visible+1)
    for idx in range(scroll, min(scroll+visible, len(SHOP_ITEMS))):
        item=SHOP_ITEMS[idx]
        iy=start_y+(idx-scroll)*item_h
        selected=(idx==sel)
        row=pygame.Surface((WIDTH-32,item_h-4),pygame.SRCALPHA)
        if selected:
            row.fill((40,40,120,220))
            pygame.draw.rect(row,(120,120,255,220),(0,0,WIDTH-32,item_h-4),2,border_radius=8)
        else:
            row.fill((15,15,45,160))
        surface.blit(row,(16,iy))
        ic_col=item.get("color",CYAN)
        pygame.draw.circle(surface,ic_col,(42,iy+item_h//2-2),16)
        pygame.draw.circle(surface,WHITE,(42,iy+item_h//2-2),16,2)
        il=small_font.render(item.get("icon","?"),True,WHITE)
        surface.blit(il,il.get_rect(center=(42,iy+item_h//2-2)))
        can=stats.coins>=item.get("price",item.get("cost",0))
        nl=font.render(item["name"],True,WHITE if selected else (200,200,200))
        surface.blit(nl,(66,iy+4))
        dl=tiny_font.render(item.get("desc",""),True,(150,150,200))
        surface.blit(dl,(66,iy+26))
        pr=small_font.render(f"{item.get('price',0)}c",True,GOLD if can else RED)
        surface.blit(pr,(WIDTH-60,iy+item_h//2-pr.get_height()//2))

    # scroll indicator
    if len(SHOP_ITEMS)>visible:
        sb_h=int((HEIGHT-85)*(visible/len(SHOP_ITEMS)))
        sb_y=int(78+(HEIGHT-85-sb_h)*(scroll/max(1,len(SHOP_ITEMS)-visible)))
        pygame.draw.rect(surface,(80,80,160),(WIDTH-8,78,6,HEIGHT-90),border_radius=3)
        pygame.draw.rect(surface,(180,180,255),(WIDTH-8,sb_y,6,sb_h),border_radius=3)

    if shop_obj.message_timer>0 and shop_obj.message_timer>0:
        mg=font.render(shop_obj.message,True,YELLOW)
        surface.blit(mg,(WIDTH//2-mg.get_width()//2,HEIGHT-32))
    else:
        hint=tiny_font.render("UP/DOWN: Select  ENTER/Tap: Buy  Tab/X: Close",True,(100,100,140))
        surface.blit(hint,(WIDTH//2-hint.get_width()//2,HEIGHT-16))
    # close button (top-right, always visible)
    close_r=pygame.Rect(WIDTH-44,6,36,36)
    pygame.draw.rect(surface,(180,40,40),(close_r),border_radius=8)
    pygame.draw.rect(surface,(255,100,100),(close_r),2,border_radius=8)
    xl=font.render("X",True,WHITE)
    surface.blit(xl,xl.get_rect(center=close_r.center))

def draw_upgrade_tree(surface,sel=0):
    ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); ov.fill((0,0,20,220)); surface.blit(ov,(0,0))
    hdr=big_font.render("UPGRADES",True,CYAN)
    surface.blit(hdr,(WIDTH//2-hdr.get_width()//2,8))
    cl=font.render(f"Coins: {stats.coins}",True,GOLD)
    surface.blit(cl,(WIDTH//2-cl.get_width()//2,42))
    pygame.draw.line(surface,GRAY,(20,64),(WIDTH-20,64),1)
    item_h=58
    for i,u in enumerate(UPGRADE_TREE):
        y=72+i*item_h; lv=upgrade_tree.levels[u["id"]]
        ok,cost=upgrade_tree.can_buy(u["id"])
        selected=(i==sel)
        row=pygame.Surface((WIDTH-32,item_h-4),pygame.SRCALPHA)
        if selected:
            row.fill((20,60,80,220))
            pygame.draw.rect(row,(0,200,255,200),(0,0,WIDTH-32,item_h-4),2,border_radius=8)
        else: row.fill((15,15,45,160))
        surface.blit(row,(16,y))
        col=CYAN if ok else GRAY
        nm=font.render(f"{u['icon']} {u['name']}",True,col if selected else WHITE)
        surface.blit(nm,(36,y+6))
        dc=tiny_font.render(u["desc"],True,(150,150,200))
        surface.blit(dc,(36,y+26))
        # pip bar
        for p in range(u["max"]):
            px=WIDTH//2+p*18; py=y+item_h//2
            pygame.draw.circle(surface,CYAN if p<lv else (50,50,70),(px,py),5)
            pygame.draw.circle(surface,WHITE if p<lv else GRAY,(px,py),5,1)
        # cost
        if lv<u["max"]:
            cr=small_font.render(f"{cost}c",True,GOLD if ok else RED)
        else:
            cr=small_font.render("MAX",True,GRAY)
        surface.blit(cr,(WIDTH-54,y+item_h//2-cr.get_height()//2))
    hint=tiny_font.render("UP/DOWN: Select  ENTER: Buy  Tab: Close",True,(80,80,120))
    surface.blit(hint,(WIDTH//2-hint.get_width()//2,HEIGHT-16))

def draw_achievements(surface):
    ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); ov.fill((0,0,20,220)); surface.blit(ov,(0,0))
    hdr=big_font.render("ACHIEVEMENTS",True,GOLD)
    surface.blit(hdr,(WIDTH//2-hdr.get_width()//2,8))
    pygame.draw.line(surface,GRAY,(20,52),(WIDTH-20,52),1)
    for i,ach in enumerate(ACHIEVEMENTS):
        y=58+i*46; done=ach["id"] in achievements.unlocked
        col=(255,200,50) if done else (80,80,100)
        panel=pygame.Surface((WIDTH-32,40),pygame.SRCALPHA)
        panel.fill((30,25,0,180) if done else (15,15,30,140))
        pygame.draw.rect(panel,(col[0]//2,col[1]//2,col[2]//2,160),(0,0,WIDTH-32,40),1,border_radius=6)
        surface.blit(panel,(16,y))
        chk=font.render("V" if done else "?",True,col)
        surface.blit(chk,(26,y+10))
        nm=small_font.render(ach["name"],True,col); surface.blit(nm,(50,y+4))
        dc=tiny_font.render(ach["desc"],True,(140,140,160)); surface.blit(dc,(50,y+22))
        rw=tiny_font.render(f"+{ach['reward']}c",True,GOLD if done else GRAY)
        surface.blit(rw,(WIDTH-50,y+12))
    hint=tiny_font.render("Tab: Close",True,(80,80,120))
    surface.blit(hint,(WIDTH//2-hint.get_width()//2,HEIGHT-16))

async def main():
    game           = GameManager()
    touch          = TouchControls()
    demo_game      = GameManager()
    auto_fire      = True
    auto_fire_tick = 0
    tick           = 0
    state          = "title"
    title_tick     = 0
    shop_tap_item  = -1
    upgrade_sel    = 0
    ach_scroll     = 0
    skin_sel       = 0
    title_sel      = 0
    stage_sel      = 0   # 0-indexed stage selection
    ending_tick    = 0

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                stats.save(); return

            raw_pos = None
            if event.type == pygame.MOUSEBUTTONDOWN:
                raw_pos = event.pos
            elif event.type == pygame.FINGERDOWN:
                raw_pos = (int(event.x*WIDTH), int(event.y*HEIGHT))

            if raw_pos is not None:
                sounds.on_user_event()
                touch.handle_touch(raw_pos, True,
                    getattr(event,'finger_id',0) if event.type==pygame.FINGERDOWN else 0)

                if state == "title":
                    state = "playing"
                elif state == "gameover":
                    ranking.submit(game.player.score,game.stage,stats.pilot_level)
                    state = "ranking"
                elif state == "ranking":
                    game = GameManager(); touch = TouchControls(); state = "playing"
                elif state == "shop":
                    # X button (top-right) or top area -> close shop
                    close_hit=(WIDTH-44 <= raw_pos[0] <= WIDTH-8 and 6 <= raw_pos[1] <= 42)
                    top_hit=raw_pos[1] < 70
                    if close_hit or top_hit:
                        state = "playing"
                    else:
                        item_h=56; start_y=78; visible=8
                        scroll=max(0, shop.selected-visible+1)
                        tapped_item=False
                        for idx in range(scroll, min(scroll+visible, len(SHOP_ITEMS))):
                            iy=start_y+(idx-scroll)*item_h
                            if iy <= raw_pos[1] <= iy+item_h:
                                tapped_item=True
                                if shop.selected == idx:
                                    result=shop.buy(game.player)
                                    if result=="bomb": game._screen_clear()
                                else:
                                    shop.selected=idx
                                break
                        # tap completely outside items -> close
                        if not tapped_item and raw_pos[1] > start_y+visible*item_h:
                            state = "playing"
                elif state == "skin_shop":
                    close_hit=(WIDTH-44<=raw_pos[0]<=WIDTH-8 and 6<=raw_pos[1]<=42)
                    if close_hit or raw_pos[1]<70:
                        state="playing"
                    else:
                        item_h=62
                        for i,sk in enumerate(SKINS):
                            y=70+i*item_h
                            if y<=raw_pos[1]<=y+item_h:
                                if skin_sel==i:
                                    if sk["id"] in stats.owned_skins:
                                        stats.skin=sk["id"]; stats.save()
                                    elif stats.coins>=sk["price"]:
                                        stats.coins-=sk["price"]
                                        stats.owned_skins.add(sk["id"])
                                        stats.skin=sk["id"]; stats.save()
                                else: skin_sel=i
                                break
                elif state == "title_select":
                    close_hit=(WIDTH-44<=raw_pos[0]<=WIDTH-8 and 6<=raw_pos[1]<=42)
                    if close_hit or raw_pos[1]<58:
                        state="playing"
                    else:
                        item_h=52
                        for i,t in enumerate(TITLES):
                            y=58+i*item_h
                            if y<=raw_pos[1]<=y+item_h:
                                if t["id"] in stats.unlocked_titles:
                                    stats.active_title=t["id"]; stats.save()
                                title_sel=i; break
                elif state == "stage_select":
                    close_hit=(WIDTH-44<=raw_pos[0]<=WIDTH-8 and 6<=raw_pos[1]<=42)
                    if close_hit:
                        state="playing"
                    else:
                        cols=10; cell_w=(WIDTH-32)//cols; cell_h=32
                        for row in range(10):
                            for col in range(10):
                                sg=row*cols+col+1
                                x=16+col*cell_w; y=72+row*cell_h
                                if x<=raw_pos[0]<=x+cell_w and y<=raw_pos[1]<=y+cell_h:
                                    if stage_sel==sg-1:
                                        # double-tap = start
                                        if sg<=stats.max_stage_cleared+1:
                                            game=GameManager(); game.stage=sg
                                            game._spawn_enemies()
                                            touch=TouchControls(); state="playing"
                                    else: stage_sel=sg-1
                elif state == "ending":
                    stats.save(); game=GameManager(); touch=TouchControls(); state="title"
                    for i in range(len(UPGRADE_TREE)):
                        y=72+i*item_h
                        if y <= raw_pos[1] <= y+item_h:
                            if upgrade_sel==i:
                                upgrade_tree.buy(UPGRADE_TREE[i]["id"])
                            else:
                                upgrade_sel=i
                            break
                elif state == "playing":
                    if game.levelup_screen and not game.levelup_screen.done:
                        game.levelup_screen.handle_tap(raw_pos)
                    else:
                        if touch.pause_tapped:
                            state = "paused"; touch.pause_tapped = False
                        if touch.shop_held:
                            state = "shop"; touch.shop_held = False
                        if touch.music_tapped:
                            sounds.toggle(); touch._music_on=sounds.enabled; touch.music_tapped=False
                elif state == "paused":
                    if touch.pause_tapped:
                        state = "playing"; touch.pause_tapped = False
                    if touch.shop_held:
                        state = "shop"; touch.shop_held = False
                    if touch.music_tapped:
                        sounds.toggle(); touch._music_on=sounds.enabled; touch.music_tapped=False

            if event.type in (pygame.MOUSEBUTTONUP, pygame.FINGERUP):
                fid = getattr(event,'finger_id',0) if event.type==pygame.FINGERUP else 0
                touch.handle_touch((0,0), False, fid)
                touch.shop_held=False; touch.pause_tapped=False; touch.music_tapped=False

            elif event.type == pygame.FINGERMOTION:
                pos=(int(event.x*WIDTH), int(event.y*HEIGHT))
                touch.handle_motion(pos, int(event.finger_id))

            elif event.type == pygame.MOUSEMOTION:
                if pygame.mouse.get_pressed()[0]:
                    touch.handle_motion(event.pos, 0)

            elif event.type == pygame.KEYDOWN:
                sounds.on_user_event()

                if event.key == pygame.K_r:
                    if state in ("gameover","title","ranking"):
                        ranking.submit(game.player.score,game.stage,stats.pilot_level)
                        game=GameManager(); touch=TouchControls(); state="playing"

                if state=="playing" and game.levelup_screen and not game.levelup_screen.done:
                    game.levelup_screen.handle_key(event.key)
                    continue

                if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    if state=="title": state="playing"
                    elif state=="ranking": game=GameManager(); touch=TouchControls(); state="playing"
                    elif state=="shop":
                        result=shop.buy(game.player)
                        if result=="bomb": game._screen_clear()
                    elif state=="upgrade":
                        upgrade_tree.buy(UPGRADE_TREE[upgrade_sel]["id"])

                if event.key == pygame.K_f: auto_fire = not auto_fire
                if event.key == pygame.K_p:
                    if state=="playing": state="paused"
                    elif state=="paused": state="playing"
                if event.key == pygame.K_TAB:
                    if state=="playing": state="shop"
                    elif state in ("shop","upgrade","achievement",
                                   "skin_shop","title_select","stage_select"): state="playing"
                if event.key == pygame.K_u:
                    if state=="playing": state="upgrade"
                    elif state=="upgrade": state="playing"
                if event.key == pygame.K_h:   # H = Hangar (skin shop)
                    if state=="playing": state="skin_shop"
                    elif state=="skin_shop": state="playing"
                if event.key == pygame.K_t:   # T = Titles
                    if state=="playing": state="title_select"
                    elif state=="title_select": state="playing"
                if event.key == pygame.K_g:   # G = Go to stage
                    if state=="playing": state="stage_select"
                    elif state=="stage_select": state="playing"
                if event.key == pygame.K_F1:
                    if state=="playing": state="achievement"
                    elif state=="achievement": state="playing"
                if event.key == pygame.K_m:
                    sounds.toggle(); touch._music_on=sounds.enabled
                if event.key == pygame.K_ESCAPE:
                    if state in ("shop","upgrade","achievement",
                                 "skin_shop","title_select","stage_select"): state="playing"
                    elif state=="paused": state="playing"
                    elif state in ("ending","ranking"): state="title"
                    else: stats.save(); return

                if state=="shop":
                    if event.key == pygame.K_UP:   shop.selected=max(0,shop.selected-1)
                    elif event.key == pygame.K_DOWN: shop.selected=min(len(SHOP_ITEMS)-1,shop.selected+1)
                elif state=="upgrade":
                    if event.key == pygame.K_UP:    upgrade_sel=max(0,upgrade_sel-1)
                    elif event.key == pygame.K_DOWN: upgrade_sel=min(len(UPGRADE_TREE)-1,upgrade_sel+1)
                elif state=="skin_shop":
                    if event.key == pygame.K_UP:    skin_sel=max(0,skin_sel-1)
                    elif event.key == pygame.K_DOWN: skin_sel=min(len(SKINS)-1,skin_sel+1)
                    elif event.key in (pygame.K_RETURN,pygame.K_KP_ENTER):
                        sk=SKINS[skin_sel]
                        if sk["id"] in stats.owned_skins:
                            stats.skin=sk["id"]; stats.save()
                        elif stats.coins>=sk["price"]:
                            stats.coins-=sk["price"]; stats.owned_skins.add(sk["id"])
                            stats.skin=sk["id"]; stats.save()
                elif state=="title_select":
                    if event.key == pygame.K_UP:    title_sel=max(0,title_sel-1)
                    elif event.key == pygame.K_DOWN: title_sel=min(len(TITLES)-1,title_sel+1)
                    elif event.key in (pygame.K_RETURN,pygame.K_KP_ENTER):
                        t=TITLES[title_sel]
                        if t["id"] in stats.unlocked_titles:
                            stats.active_title=t["id"]; stats.save()
                elif state=="stage_select":
                    if event.key == pygame.K_LEFT:  stage_sel=max(0,stage_sel-1)
                    elif event.key == pygame.K_RIGHT: stage_sel=min(99,stage_sel+1)
                    elif event.key == pygame.K_UP:  stage_sel=max(0,stage_sel-10)
                    elif event.key == pygame.K_DOWN: stage_sel=min(99,stage_sel+10)
                    elif event.key in (pygame.K_RETURN,pygame.K_KP_ENTER):
                        sg=stage_sel+1
                        if sg<=stats.max_stage_cleared+1:
                            game=GameManager(); game.stage=sg
                            game._spawn_enemies()
                            touch=TouchControls(); state="playing"
                elif state=="ending":
                    if event.key == pygame.K_r:
                        stats.save(); game=GameManager(); touch=TouchControls(); state="title"

        # -- draw --
        screen.fill(BLACK)
        shop.update()

        if state == "title":
            title_tick += 1
            dk={"dx":0,"dy":0,"left":False,"right":False,"up":False,"down":False,
                "shoot":True,"charge":False,"special":False}
            if demo_game.player.lives > 0: demo_game.update(dk, touch)
            else: demo_game = GameManager()
            draw_title(screen, title_tick, demo_game)

        elif state == "playing":
            pressed=pygame.key.get_pressed()
            auto_fire_tick+=1

            if game.levelup_screen and not game.levelup_screen.done:
                game.draw(screen)
                game.levelup_screen.draw(screen)
            else:
                if game.levelup_screen and game.levelup_screen.done:
                    game.levelup_screen=None
                # slowmo during boss killcam
                slow_frames = 2 if kill_effect.is_slow else 1
                for _ in range(slow_frames if not kill_effect.is_slow else 1):
                    shoot=touch.is_pressed("shoot") or pressed[pygame.K_SPACE]
                    if auto_fire and auto_fire_tick%3==0: shoot=True
                    jdx,jdy=touch.get_joy_axis()
                    kdx=(-1 if pressed[pygame.K_LEFT] or pressed[pygame.K_a] else 0)+(1 if pressed[pygame.K_RIGHT] or pressed[pygame.K_d] else 0)
                    kdy=(-1 if pressed[pygame.K_UP]   or pressed[pygame.K_w] else 0)+(1 if pressed[pygame.K_DOWN]  else 0)
                    fdx=jdx if touch.joy_active else float(kdx)
                    fdy=jdy if touch.joy_active else float(kdy)
                    # dash on C key or double-tap detection
                    if pressed[pygame.K_c] and game.player.dash_cd==0:
                        game.player.try_dash(fdx,fdy)
                    sp_touch=touch.is_pressed("special")
                    use_sp=(game.player.special_ready and sp_touch) or pressed[pygame.K_x]
                    keys={"dx":fdx,"dy":fdy,"left":fdx<-0.3,"right":fdx>0.3,
                          "up":fdy<-0.3,"down":fdy>0.3,"shoot":shoot,
                          "charge":sp_touch or pressed[pygame.K_z] or pressed[pygame.K_LSHIFT],
                          "special":use_sp}
                    # skip update every other frame during slowmo
                    if kill_effect.is_slow and (auto_fire_tick%2==0):
                        pass
                    elif game.player.lives>0:
                        game.update(keys,touch)
                        if game.player.score>stats.high_score: stats.high_score=game.player.score
                        # stage 100 clear -> ending
                        if game.stage>100 and not game.enemies and not game.boss:
                            stats.max_stage_cleared=max(stats.max_stage_cleared,100)
                            stats.unlock_title("champion"); stats.save()
                            ending_tick=0; state="ending"
                    else:
                        ranking.submit(game.player.score,game.stage,stats.pilot_level)
                        state="ranking"
                touch._sp_ready=game.player.special_ready
                game.draw(screen)
            touch.draw(screen)
            af=tiny_font.render(f"AUTO {'ON' if auto_fire else 'OFF'}",True,CYAN if auto_fire else GRAY)
            screen.blit(af,(WIDTH//2-22,HEIGHT-20))
            # dash cooldown indicator
            pl=game.player
            if pl.dash_cd>0:
                ratio=1-pl.dash_cd/45
                pygame.draw.rect(screen,(40,40,80),(8,HEIGHT-36,60,6),border_radius=3)
                pygame.draw.rect(screen,(100,200,255),(8,HEIGHT-36,int(60*ratio),6),border_radius=3)
                dl=tiny_font.render("DASH",True,(100,200,255))
                screen.blit(dl,(8,HEIGHT-48))
            else:
                dl=tiny_font.render("DASH [C]",True,(0,200,255))
                screen.blit(dl,(8,HEIGHT-48))
            uh=tiny_font.render("U=Upgrades  F1=Achievements",True,(60,60,90))
            screen.blit(uh,(8,HEIGHT-20))

        elif state == "paused":
            game.draw(screen); draw_pause(screen); touch.draw(screen)

        elif state == "shop":
            game.draw(screen); draw_shop_full(screen,shop,game.player); touch.draw(screen)

        elif state == "upgrade":
            game.draw(screen); draw_upgrade_tree(screen,upgrade_sel)

        elif state == "achievement":
            game.draw(screen); draw_achievements(screen)

        elif state == "skin_shop":
            game.draw(screen); draw_skin_shop(screen,skin_sel)

        elif state == "title_select":
            game.draw(screen); draw_title_select(screen,title_sel)

        elif state == "stage_select":
            game.draw(screen); draw_stage_select(screen,stage_sel)

        elif state == "ending":
            ending_tick+=1
            draw_ending(screen,ending_tick)

        elif state == "ranking":
            ranking.draw(screen)

        elif state == "gameover":
            game.draw(screen)
            ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); ov.fill((0,0,0,170)); screen.blit(ov,(0,0))
            screen.blit(big_font.render("GAME OVER",True,RED),(WIDTH//2-big_font.size("GAME OVER")[0]//2,HEIGHT//2-60))
            screen.blit(font.render(f"Score: {game.player.score:,}",True,WHITE),(WIDTH//2-75,HEIGHT//2))
            screen.blit(font.render(f"Best:  {stats.high_score:,}",True,GOLD),(WIDTH//2-75,HEIGHT//2+28))
            if (pygame.time.get_ticks()//500)%2==0:
                screen.blit(font.render("Tap or R to continue",True,GRAY),(WIDTH//2-85,HEIGHT//2+62))

        pygame.display.flip()
        if IS_WEB:
            clock.tick(0)
            await asyncio.sleep(1/60)
        else:
            clock.tick(FPS)
            await asyncio.sleep(0)

asyncio.run(main())